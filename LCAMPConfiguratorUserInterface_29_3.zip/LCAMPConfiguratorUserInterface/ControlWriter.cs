﻿

#pragma warning disable CA1416

namespace LCAMPConfigurator.UI
{
    using System;
    using System.IO;
    using System.Text;
    using System.Windows.Forms;
    using System.Drawing;
    using System.Diagnostics;
    using System.Collections.Generic;


    public class ControlWriter : TextWriter
    {
        private readonly RichTextBox _textControl;
        private delegate void WriteDelegate(string value);
        public override Encoding Encoding => Encoding.UTF8;


        private StringBuilder buffer = new StringBuilder();

        public ControlWriter(RichTextBox control)
        {
            _textControl = control;
        }



        public override void Write(string value)
        {
            if (_textControl.InvokeRequired)
                _textControl.Invoke(new WriteDelegate(Write), value);
            else
                WriteFormated(value);
        }

        public override void WriteLine(string value)
        {
            Write(value + Environment.NewLine);
        }

        public void WriteFormated(string value) {
            // Position ans Ende setzen
            _textControl.SelectionStart = _textControl.TextLength;
            _textControl.SelectionLength = 0;

            if (value.Trim().StartsWith("Warning"))
            {
                _textControl.SelectionColor = Color.DarkRed;// Farbe setzen
                _textControl.SelectionFont = new Font(_textControl.Font, FontStyle.Regular);
            }
            else if (value.Trim().StartsWith("Error"))
            {
                _textControl.SelectionColor = Color.Red;// Farbe setzen
                _textControl.SelectionFont = new Font(_textControl.Font, FontStyle.Regular);
            }
            else if (value.Trim().StartsWith("Action")) {
                _textControl.SelectionColor = Color.DarkBlue;// Farbe setzen
                _textControl.SelectionFont = new Font("Consolas", 12, FontStyle.Bold);// Schriftart setzen
         //       _textControl.AppendText(Environment.NewLine);  // lerzeile davor einschieben
            }
            else
            {
                _textControl.SelectionColor = _textControl.ForeColor;
                _textControl.SelectionFont = _textControl.Font;
            }

            _textControl.AppendText(value.ToString());

            // Farbe und Schriftart zurücksetzen
        //    _textControl.SelectionColor = _textControl.ForeColor;
        //    _textControl.SelectionFont = _textControl.Font;

            // Automatisch scrollen
            _textControl.ScrollToCaret();
        }
       
        }

        // Hauptformular mit verschiedenen Umleitungsmethoden
        public partial class ConsoleRedirectForm : Form
        {
            private Label labelOutput;
            private RichTextBox textBoxOutput;
            private Button btnTest1, btnTest2, btnTest3, btnTest4;
            private Button btnClear;
            private TabControl tabControl;

            public ConsoleRedirectForm()
            {
                InitializeComponent();
                SetupConsoleRedirection();
        }

            private void InitializeComponent()
            {
                this.Size = new Size(800, 600);
                this.Text = "Console.WriteLine Umleitung Beispiele";
                this.StartPosition = FormStartPosition.CenterScreen;

                // TabControl erstellen
                tabControl = new TabControl
                {
                    Dock = DockStyle.Fill
                };

                // Tab 1: TextBox
                var tabPage1 = new TabPage("TextBox");
                textBoxOutput = new RichTextBox
                {
                    Multiline = true,
                    Dock = DockStyle.Fill,
                    Font = new Font("Consolas", 9),
                    ReadOnly = true
                };
                tabPage1.Controls.Add(textBoxOutput);
                tabControl.TabPages.Add(tabPage1);

                // Tab 2: Label (für kurze Ausgaben)
                var tabPage2 = new TabPage("Label");
                labelOutput = new Label
                {
                    Dock = DockStyle.Fill,
                    Font = new Font("Consolas", 9),
                    BackColor = Color.White,
                    BorderStyle = BorderStyle.FixedSingle,
                    Text = "Console-Ausgabe erscheint hier...\n"
                };
                tabPage2.Controls.Add(labelOutput);
                tabControl.TabPages.Add(tabPage2);

                // Tab 3: RichTextBox (mit Formatierung)
                var tabPage3 = new TabPage("RichTextBox");
                textBoxOutput = new RichTextBox
                {
                    Dock = DockStyle.Fill,
                    Font = new Font("Consolas", 9),
                    ReadOnly = true
                };
                tabPage3.Controls.Add(textBoxOutput);
                tabControl.TabPages.Add(tabPage3);

                // Button Panel
                var buttonPanel = new Panel
                {
                    Height = 50,
                    Dock = DockStyle.Bottom
                };

                btnTest1 = new Button { Text = "TextBox Test", Location = new Point(10, 10), Size = new Size(100, 30) };
                btnTest2 = new Button { Text = "Label Test", Location = new Point(120, 10), Size = new Size(100, 30) };
                btnTest3 = new Button { Text = "RichTextBox Test", Location = new Point(230, 10), Size = new Size(120, 30) };
                btnTest4 = new Button { Text = "Alle Tests", Location = new Point(360, 10), Size = new Size(100, 30) };
                btnClear = new Button { Text = "Löschen", Location = new Point(470, 10), Size = new Size(80, 30) };

                buttonPanel.Controls.AddRange(new Control[] { btnTest1, btnTest2, btnTest3, btnTest4, btnClear });

                // Event Handler
                btnTest1.Click += BtnTest1_Click;
                btnTest2.Click += BtnTest2_Click;
                btnTest3.Click += BtnTest3_Click;
                btnTest4.Click += BtnTest4_Click;
                btnClear.Click += BtnClear_Click;

                // Controls zum Form hinzufügen
                this.Controls.Add(tabControl);
                this.Controls.Add(buttonPanel);
            }

            private void SetupConsoleRedirection()
            {
                // Standard Console-Umleitung auf TextBox
                Console.SetOut(new ControlWriter(textBoxOutput));
            }

            // Methode 2: Wrapper-Klasse für erweiterte Funktionalität
            public class ConsoleHelper
            {
                private static Control outputControl;
                private static bool enableTimestamp = false;

                public static void SetOutputControl(Control control)
                {
                    outputControl = control;
                }

                public static void EnableTimestamp(bool enable)
                {
                    enableTimestamp = enable;
                }

                public static void WriteLine(string message)
                {
                    string output = enableTimestamp ? $"[{DateTime.Now:HH:mm:ss}] {message}" : message;
                    WriteToControl(output + Environment.NewLine);
                }

                public static void Write(string message)
                {
                    WriteToControl(message);
                }

                public static void WriteError(string message)
                {
                    string output = $"ERROR: {message}";
                    WriteToControl(output + Environment.NewLine, Color.Red);
                }

                public static void WriteSuccess(string message)
                {
                    string output = $"SUCCESS: {message}";
                    WriteToControl(output + Environment.NewLine, Color.Green);
                }

                public static void WriteWarning(string message)
                {
                    string output = $"WARNING: {message}";
                    WriteToControl(output + Environment.NewLine, Color.Orange);
                }

                private static void WriteToControl(string message, Color? color = null)
                {
                    if (outputControl == null) return;

                    if (outputControl.InvokeRequired)
                    {
                        outputControl.Invoke(new Action(() => AppendText(message, color)));
                    }
                    else
                    {
                        AppendText(message, color);
                    }
                }

                private static void AppendText(string message, Color? color)
                {
                    if (outputControl is RichTextBox rtb)
                    {
                        int start = rtb.TextLength;
                        rtb.AppendText(message);
                        if (color.HasValue)
                        {
                            rtb.Select(start, message.Length);
                            rtb.SelectionColor = color.Value;
                            rtb.Select(rtb.TextLength, 0);
                        }
                        rtb.ScrollToCaret();
                    }
                    else if (outputControl is TextBox tb)
                    {
                        tb.AppendText(message);
                        tb.ScrollToCaret();
                    }
                    else if (outputControl is Label lbl)
                    {
                        lbl.Text += message;
                        if (color.HasValue) lbl.ForeColor = color.Value;
                    }
                }

                public static void Clear()
                {
                    if (outputControl?.InvokeRequired == true)
                    {
                        outputControl.Invoke(new Action(() => ClearControl()));
                    }
                    else
                    {
                        ClearControl();
                    }
                }

                private static void ClearControl()
                {
                    if (outputControl != null)
                    {
                        outputControl.Text = "";
                    }
                }
            }

            // Event Handler für Tests
            private void BtnTest1_Click(object sender, EventArgs e)
            {
                tabControl.SelectedIndex = 0; // TextBox Tab
                Console.SetOut(new ControlWriter(textBoxOutput));
                RunConsoleTest("TextBox");
            }

            private void BtnTest2_Click(object sender, EventArgs e)
            {
                tabControl.SelectedIndex = 1; // Label Tab
                Console.SetOut(new ControlWriter(textBoxOutput));
                RunConsoleTest("Label");
            }

            private void BtnTest3_Click(object sender, EventArgs e)
            {
                tabControl.SelectedIndex = 2; // RichTextBox Tab
                ConsoleHelper.SetOutputControl(textBoxOutput);
                ConsoleHelper.EnableTimestamp(true);
                RunConsoleHelperTest();
            }

            private void BtnTest4_Click(object sender, EventArgs e)
            {
                // Alle Tests durchlaufen
                BtnTest1_Click(sender, e);
                System.Threading.Thread.Sleep(1000);
                BtnTest2_Click(sender, e);
                System.Threading.Thread.Sleep(1000);
                BtnTest3_Click(sender, e);
            }

            private void BtnClear_Click(object sender, EventArgs e)
            {
                labelOutput.Text = "";
                textBoxOutput.Clear();
                ConsoleHelper.Clear();
            }

            private void RunConsoleTest(string target)
            {
                Console.WriteLine($"=== Console-Test für {target} ===");
                Console.WriteLine($"Zeitstempel: {DateTime.Now}");
                Console.WriteLine("Das ist eine normale Ausgabe.");
                Console.WriteLine("Mehrzeilige");
                Console.WriteLine("Ausgabe");
                Console.WriteLine("funktioniert auch.");

                // Simulation einer längeren Operation
                for (int i = 1; i <= 5; i++)
                {
                    Console.WriteLine($"Schritt {i}/5 abgeschlossen...");
                    Application.DoEvents(); // UI aktualisieren
                    System.Threading.Thread.Sleep(200);
                }

                Console.WriteLine("Test abgeschlossen!\n");
            }

            private void RunConsoleHelperTest()
            {
                ConsoleHelper.WriteLine("=== ConsoleHelper-Test für RichTextBox ===");
                ConsoleHelper.WriteSuccess("Das ist eine Erfolgsmeldung");
                ConsoleHelper.WriteError("Das ist eine Fehlermeldung");
                ConsoleHelper.WriteWarning("Das ist eine Warnung");
                ConsoleHelper.WriteLine("Normale Nachricht mit Zeitstempel");
                ConsoleHelper.WriteLine("Test abgeschlossen!\n");
            }
        }

        // Methode 3: Extension Methods für einfache Verwendung
        public static class ControlExtensions
        {
            public static void WriteLineToControl(this Control control, string message)
            {
                if (control.InvokeRequired)
                {
                    control.Invoke(new Action(() => control.WriteLineToControl(message)));
                    return;
                }

                string output = message + Environment.NewLine;

                if (control is TextBox textBox)
                {
                    textBox.AppendText(output);
                    textBox.ScrollToCaret();
                }
                else if (control is RichTextBox richTextBox)
                {
                    richTextBox.AppendText(output);
                    richTextBox.ScrollToCaret();
                }
                else if (control is Label label)
                {
                    label.Text += output;
                }
            }

            public static void ClearOutput(this Control control)
            {
                if (control.InvokeRequired)
                {
                    control.Invoke(new Action(() => control.ClearOutput()));
                    return;
                }

                control.Text = "";
            }
        }

        // Methode 4: Logger-Klasse mit verschiedenen Zielen
        public class FormLogger
        {
            public enum LogLevel
            {
                Info,
                Warning,
                Error,
                Debug
            }

            private Control targetControl;
            private bool showTimestamp;
            private bool showLogLevel;

            public FormLogger(Control target, bool timestamp = true, bool logLevel = true)
            {
                targetControl = target;
                showTimestamp = timestamp;
                showLogLevel = logLevel;
            }

            public void Log(string message, LogLevel level = LogLevel.Info)
            {
                string output = FormatMessage(message, level);
                WriteToTarget(output, GetColorForLevel(level));
            }

            private string FormatMessage(string message, LogLevel level)
            {
                var parts = new List<string>();

                if (showTimestamp)
                    parts.Add($"[{DateTime.Now:HH:mm:ss}]");

                if (showLogLevel)
                    parts.Add($"[{level.ToString().ToUpper()}]");

                parts.Add(message);

                return string.Join(" ", parts);
            }

            private Color GetColorForLevel(LogLevel level)
            {
                switch (level)
                {
                    case LogLevel.Error: return Color.Red;
                    case LogLevel.Warning: return Color.Orange;
                    case LogLevel.Debug: return Color.Gray;
                    default: return Color.Black;
                }
            }

            private void WriteToTarget(string message, Color color)
            {
                if (targetControl?.InvokeRequired == true)
                {
                    targetControl.Invoke(new Action(() => AppendToTarget(message + Environment.NewLine, color)));
                }
                else
                {
                    AppendToTarget(message + Environment.NewLine, color);
                }
            }

            private void AppendToTarget(string message, Color color)
            {
                if (targetControl is RichTextBox rtb)
                {
                    int start = rtb.TextLength;
                    rtb.AppendText(message);
                    rtb.Select(start, message.Length);
                    rtb.SelectionColor = color;
                    rtb.Select(rtb.TextLength, 0);
                    rtb.ScrollToCaret();
                }
                else if (targetControl is TextBox tb)
                {
                    tb.AppendText(message);
                    tb.ScrollToCaret();
                }
                else if (targetControl is Label label)
                {
                    label.Text += message;
                    label.ForeColor = color;
                }
            }
        }



   




}
