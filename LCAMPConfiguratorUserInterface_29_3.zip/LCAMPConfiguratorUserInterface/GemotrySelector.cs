﻿
#pragma warning disable CA1416

using LCAMPConfigurator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LCAMPConfigurator.Core;
using System.Numerics;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LCAMPConfigurator.UI
{
    public partial class GemotrySelector : Form
    {

        private LinkDefinition _aLink;
        public LinkDefinition aLink
        {
            get { return _aLink; }
            set { _aLink = value; if (_aLink != null) labelBoundingBox.Text = $"Size [{_aLink.box.ToString()}]"; }
        }


        //   string bBoxToString(Size3 x)
        //   {
        //       return $"size( {x.W} , {x.W} , {x.H} )";
        //   }

        public GemotrySelector()
        {
            InitializeComponent();
        }


        public void SetValues(LinkDefinition link)
        {
            if (link != null)
            {
                numericUpDownX.Value = Convert.ToDecimal(link.X);
                numericUpDownY.Value = Convert.ToDecimal(link.Y);
                numericUpDownZ.Value = Convert.ToDecimal(link.Z);
                numericUpDownRotX.Value = Convert.ToDecimal(link.Roll);
                numericUpDownRotY.Value = Convert.ToDecimal(link.Pitch);
                numericUpDownRotZ.Value = Convert.ToDecimal(link.Yaw);
                switch (link.JointType)
                {
                    //case "fixed": radioButton1.Checked = true; break;
                    //case "continous": radioButton2.Checked = true; break;
                    case JointTypes.Fixed: radioButton1.Checked = true; break;
                    case JointTypes.Continuous: radioButton2.Checked = true; break;

                }
                if(this.Width >650)
                 this.Width -= 200;
            }

        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (aLink == null)
                aLink = new LinkDefinition();
            aLink.SetPosition(Convert.ToSingle(numericUpDownX.Value), Convert.ToSingle(numericUpDownY.Value), Convert.ToSingle(numericUpDownZ.Value));
            aLink.SetOrientation(Convert.ToSingle(numericUpDownRotX.Value), Convert.ToSingle(numericUpDownRotY.Value), Convert.ToSingle(numericUpDownRotZ.Value));
            if (this.radioButton1.Checked)
                //                aLink.JointType = "fixed";
                aLink.JointType = JointTypes.Fixed;
            else if (this.radioButton2.Checked)
                // aLink.JointType = "continous";
                aLink.JointType = JointTypes.Continuous;


        }


        private void buttonSetBox_Click(object sender, EventArgs e)
        {
            if (!groupBox.Visible)
            {
                this.Width += 200;  
                    
                    switch (aLink.box.Type)
                {
                    case GeomType.Box: radioButton_box.Checked = true; break;
                    case GeomType.Cylinder: radioButtonCylinder.Checked = true; break;
                    case GeomType.Sphere: radioButtonSpere.Checked = true; break;
                    case GeomType.Mesh: radioButtonMesh.Checked = true; break;
                }
                groupBox.Visible = true;
                buttonSetBox.Text = "Set BoundingBox";
                numericUpDown_l.Value = (decimal)aLink.box.L;
                numericUpDown_w.Value = (decimal)aLink.box.W;
                numericUpDown_h.Value = (decimal)aLink.box.H;
                numericUpDown_r.Value = (decimal)aLink.box.R;

                if (this.radioButton_box.Checked)
                {
                    numericUpDown_l.Enabled = true;
                    label_l.Enabled = false;
                    numericUpDown_w.Enabled = true;
                    label_w.Enabled = false;
                    numericUpDown_h.Enabled = true;
                    label_h.Enabled = false;
                    numericUpDown_r.Enabled = false;
                    label_r.Enabled = false;
                }
                else if (this.radioButtonCylinder.Checked)
                {
                    numericUpDown_l.Enabled = false;
                    label_l.Enabled = false;
                    numericUpDown_w.Enabled = false;
                    label_w.Enabled = false;
                    numericUpDown_h.Enabled = true;
                    label_h.Enabled = false;
                    numericUpDown_r.Enabled = true;
                    label_r.Enabled = true;
                }
                else if (this.radioButtonSpere.Checked)
                {
                    numericUpDown_l.Enabled = false;
                    label_l.Enabled = false;
                    numericUpDown_w.Enabled = false;
                    label_w.Enabled = false;
                    numericUpDown_h.Enabled = false;
                    label_h.Enabled = false;
                    numericUpDown_r.Enabled = true;
                    label_r.Enabled = true;
                }
            }
            else
            {

                float l = Convert.ToSingle(numericUpDown_l.Value);
                float w = Convert.ToSingle(numericUpDown_w.Value);
                float h = Convert.ToSingle(numericUpDown_h.Value);
                float r = Convert.ToSingle(numericUpDown_r.Value);
                GeomType typ = GeomType.None;
                if (radioButton_box.Checked) typ = GeomType.Box;
                if (radioButtonCylinder.Checked) typ = GeomType.Cylinder;
                if (radioButtonSpere.Checked) typ = GeomType.Sphere;
                if (radioButtonMesh.Checked) typ = GeomType.Mesh;

                aLink.box = new Size3(l, w, h, r, typ);
                labelBoundingBox.Text = $"Size [{aLink.box.ToString()}]";
            }
            Console.WriteLine($"Box set: {aLink.box}");
        }
    
       

        private void radioButton_box_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown_l.Enabled = true;
            label_l.Enabled = false;
            numericUpDown_w.Enabled = true;
            label_w.Enabled = false;
            numericUpDown_h.Enabled = true;
            label_h.Enabled = false;
            numericUpDown_r.Enabled = false;
            label_r.Enabled = false;

        }

        private void radioButtonCylinder_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown_l.Enabled = false;
            label_l.Enabled = false;
            numericUpDown_w.Enabled = false;
            label_w.Enabled = false;
            numericUpDown_h.Enabled = true;
            label_h.Enabled = true;
            numericUpDown_r.Enabled = true;
            label_r.Enabled = true;
        }

        private void radioButtonSpere_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown_l.Enabled = false;
            label_l.Enabled = false;
            numericUpDown_w.Enabled = false;
            label_w.Enabled = false;
            numericUpDown_h.Enabled = false;
            label_h.Enabled = false;
            numericUpDown_r.Enabled = true;
            label_r.Enabled = true;
        }

        private void radioButtonMesh_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown_l.Enabled = false;
            label_l.Enabled = false;
            numericUpDown_w.Enabled = false;
            label_w.Enabled = false;
            numericUpDown_h.Enabled = false;
            label_h.Enabled = false;
            numericUpDown_r.Enabled = false;
            label_r.Enabled = false;
        }
    }
}
