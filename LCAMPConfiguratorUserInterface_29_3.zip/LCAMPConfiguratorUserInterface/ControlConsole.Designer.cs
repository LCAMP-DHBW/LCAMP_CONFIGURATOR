﻿using System.Drawing;
using System.Windows.Forms;


namespace LCAMPConfigurator.UI
{
    partial class ControlConsole
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxOutput = new RichTextBox();
            buttonClear = new Button();
            buttonCopy = new Button();
            SuspendLayout();
            // 
            // textBoxOutput
            // 
            textBoxOutput.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBoxOutput.BackColor = SystemColors.ControlLightLight;
            textBoxOutput.Location = new Point(27, 13);
            textBoxOutput.Margin = new Padding(3, 4, 3, 4);
            textBoxOutput.Name = "textBoxOutput";
            textBoxOutput.ReadOnly = true;
            textBoxOutput.Size = new Size(750, 424);
            textBoxOutput.TabIndex = 9;
            textBoxOutput.Text = "";
            // 
            // buttonClear
            // 
            buttonClear.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonClear.Location = new Point(713, 401);
            buttonClear.Margin = new Padding(3, 4, 3, 4);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(60, 36);
            buttonClear.TabIndex = 10;
            buttonClear.Text = "clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonCopy
            // 
            buttonCopy.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCopy.Location = new Point(713, 357);
            buttonCopy.Margin = new Padding(3, 4, 3, 4);
            buttonCopy.Name = "buttonCopy";
            buttonCopy.Size = new Size(60, 36);
            buttonCopy.TabIndex = 10;
            buttonCopy.Text = "copy";
            buttonCopy.UseVisualStyleBackColor = true;
            buttonCopy.Click += buttonCopy_Click;
            // 
            // ControlConsole
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonCopy);
            Controls.Add(buttonClear);
            Controls.Add(textBoxOutput);
            Name = "ControlConsole";
            Text = "ControlConsole";
            TopMost = true;
            FormClosing += ControlConsole_FormClosing;
            FormClosed += ControlConsole_FormClosed;
            ResumeLayout(false);
        }

        #endregion

        public RichTextBox textBoxOutput;
        private Button buttonClear;
        private Button buttonCopy;
    }
}