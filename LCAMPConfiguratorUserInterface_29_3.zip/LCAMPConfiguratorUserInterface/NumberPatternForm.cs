﻿using LCAMPConfigurator.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LCAMPConfiguratorUserInterface
{
    public partial class NumberPatternForm : Form
    {

        public string FormatPattern
        {
            get { return textBoxPattern.Text; }
            set { textBoxPattern.Text = value; update(); }
        }

        public NumberPatternForm()
        {
            InitializeComponent();
        }
        private void update()
        {
            Dictionary<string, double> data = ComponentHelper.ParseCmdLine(textBoxPattern.Text);
            int nParts = Convert.ToInt32(data["Number"]);


        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            Dictionary<string, double> data = ComponentHelper.ParseCmdLine(textBoxPattern.Text);
            int nParts = Convert.ToInt32(data["Number"]);
            string pattern;
            if (data.ContainsKey("p"))
             pattern = data["p"].ToString();
        }
    }
}
