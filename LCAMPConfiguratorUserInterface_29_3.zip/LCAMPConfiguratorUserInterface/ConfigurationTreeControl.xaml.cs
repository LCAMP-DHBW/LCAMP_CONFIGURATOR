#pragma warning disable CA1416

using LCAMPConfigurator.Core;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace LCAMPConfigurator.UI
{
    /// <summary>
    /// WPF-Konvertierung des WinForms ConfigurationTreeControl.
    /// Enthält die vollständige Geschäftslogik aus dem WinForms-Original.
    /// </summary>
    public partial class ConfigurationTreeControl : UserControl
    {
        // ── Felder ──────────────────────────────────────────────────────────────

        /// <summary>Wurzelknoten des Konfigurationsbaums.</summary>
        private TreeViewItem rootTreeNode = new TreeViewItem { Header = "LCAMP Robot" };

        /// <summary>Letzter verwendeter Ladepfad (ersetzt openFileDialogLoad.FileName).</summary>
        private string _loadedFilePath = "RobiControl.json";

        // ── Öffentliche Properties ───────────────────────────────────────────────

        /// <summary>Direktzugriff auf den internen WPF-TreeView (analog zu WinForms).</summary>
        public TreeView MyTreeViewSystem => treeViewSystem;

        /// <summary>Aktuelle Roboterkonfiguration.</summary>
        public LCAMPRobot actRobot { get; set; }

        /// <summary>Aktuelles Sub-System / Assembly.</summary>
        public SubSystem actSystem { get; set; }

        // ── Event ────────────────────────────────────────────────────────────────

        /// <summary>
        /// Wird ausgelöst, wenn sich die Konfiguration ändert (Load, Save, Clear, Update).
        /// Tuple: (Key, Value, mode, RobComponent)
        /// </summary>
        public event Action<(string Key, string Value, string mode, RobComponent comp)> ConfigurationChanged;

        // ── Konstruktor ──────────────────────────────────────────────────────────

        public ConfigurationTreeControl()
        {
            InitializeComponent();
        }

        // ── Öffentliche Methoden ─────────────────────────────────────────────────

        /// <summary>Leert den Konfigurationsbaum ohne Rückfrage.</summary>
        public void Clear()
        {
            treeViewSystem.Items.Clear();
            rootTreeNode.Items.Clear();
        }

        // ── Drag & Drop ──────────────────────────────────────────────────────────

        private void treeViewSystem_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                e.Effects = (files.Length > 0 &&
                             Path.GetExtension(files[0]).ToLower() == ".json")
                    ? DragDropEffects.Copy
                    : DragDropEffects.None;
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void treeViewSystem_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 &&
                    Path.GetExtension(files[0]).ToLower() == ".json")
                {
                    _loadedFilePath = files[0];
                    OpenFileDialogLoad_FileOk(_loadedFilePath);

                    string newTitle = $"LCAMP Configurator - {Path.GetFileName(files[0])}";
                    ConfigurationChanged?.Invoke(("Title",  newTitle,        null, null));
                    ConfigurationChanged?.Invoke(("Update", _loadedFilePath, null, actRobot));
                }
            }
            e.Handled = true;
        }

        // ── Baum-Aufbau ──────────────────────────────────────────────────────────

        /// <summary>
        /// Baut einen Zweig für eine Liste von RobComponents rekursiv auf.
        /// </summary>
        public TreeViewItem Component_configAddBranch(List<RobComponent> componentControl, string name)
        {
            Console.WriteLine($"\tT: {name}");

            if (componentControl.Count == 0)
                return null;

            var treeNode = new TreeViewItem { Header = name };

            foreach (RobComponent part in componentControl)
            {
                string pName = part.Name;
                part.Parent = name;

                if (part is PartDescription p)
                {
                    if (p.Number == null)
                        p.Number = "0";
                    else if (p.Number != "0" && p.Number != "1")
                        pName = $"{part.Name} [{p.Number}]";
                }

                if (part.Components.Count == 0)
                {
                    if (part.Status != "inactive")
                    {
                        var leaf = new TreeViewItem { Header = pName, Tag = part };
                        part.SetTreeNode(ToWinFormsNode(leaf));
                        treeNode.Items.Add(leaf);
                    }
                }
                else
                {
                    var childNode = Component_configAddBranch(part.Components, pName);
                    if (childNode != null)
                    {
                        childNode.Tag = part;
                        part.SetTreeNode(ToWinFormsNode(childNode));
                        treeNode.Items.Add(childNode);
                    }
                }
            }

            return treeNode;
        }

        /// <summary>Gibt die Komponentenhierarchie rekursiv auf der Konsole aus.</summary>
        public void listComponents(RobComponent comp, int level = 1)
        {
            Console.WriteLine(level + ": " + comp.Name);
            foreach (RobComponent part in comp.Components)
                listComponents(part, level + 1);
        }

        /// <summary>Gibt die Roboter-Komponentenstruktur auf der Konsole aus.</summary>
        public void listRobotComponents(RobComponent system, int level = 1)
        {
            try
            {
                string smf = new string('\t', level);

                if (system == null)
                {
                    Console.WriteLine("Mobile Robot or Assembly : nicht definiert");
                    return;
                }

                if (system is LCAMPRobot rob)
                    Console.WriteLine($"Mobile Robot: {rob.Name}  Serial: {rob.SerialNumber} Type: {rob.Type}");
                else if (system.Components.Count > 0)
                    Console.WriteLine($"{smf}{level}  Assembly: {system.Name}  Type: {system.Type}");
                else
                    Console.WriteLine($"{smf}{level}: {system.Name}  Type: {system.Type}");

                foreach (RobComponent part in system.Components)
                    if (part != null)
                        listRobotComponents(part, level + 1);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex);
            }
        }

        /// <summary>
        /// Baut den gesamten Konfigurationsbaum für ein SubSystem auf und zeigt ihn an.
        /// </summary>
        public TreeViewItem Robot_configAddBranch(SubSystem system)
        {
            if (system == null)
            {
                Console.WriteLine("Error: no Robot or assembly specified in Robot_configAddBranch");
                return null;
            }

            listRobotComponents(system);
            Console.WriteLine($"Build Tree from {system.Name}");

            if (system.Components.Count > 0)
            {
                var tNode = Component_configAddBranch(system.Components, system.Name);
                if (tNode != null)
                {
                    tNode.Tag = system;
                    system.SetTreeNode(ToWinFormsNode(tNode));

                    var existing = FindItemByHeader(rootTreeNode, system.Name);
                    if (existing != null)
                    {
                        int index = rootTreeNode.Items.IndexOf(existing);
                        rootTreeNode.Items.RemoveAt(index);
                        rootTreeNode.Items.Insert(index, tNode);
                        Console.WriteLine($"TreeNode '{system.Name}' wurde überschrieben.");
                    }
                    else
                    {
                        rootTreeNode.Items.Add(tNode);
                        Console.WriteLine($"Neuer TreeNode '{system.Name}' wurde hinzugefügt.");
                    }
                }
            }

            treeViewSystem.Items.Clear();
            treeViewSystem.Items.Add(rootTreeNode);
            ExpandItems(rootTreeNode, 2);

            return rootTreeNode;
        }

        /// <summary>
        /// Befüllt den TreeView aus einer tabellarischen Datenliste (level-basiert).
        /// </summary>
        public void PopulateTreeView(List<Dictionary<string, object>> tableData)
        {
            treeViewSystem.Items.Clear();

            TreeViewItem n1 = null, n2 = null, n3 = null,
                         n4 = null, n5 = null, n6 = null;

            foreach (var row in tableData)
            {
                string level = row.Values.First() as string;
                if (!int.TryParse(level, out int nodeLevel)) continue;

                string text  = row["Description"] as string;
                var    pNode = new TreeViewItem { Header = text };

                switch (nodeLevel)
                {
                    case 0:
                        n1 = pNode;
                        treeViewSystem.Items.Add(pNode);
                        break;
                    case 1:
                        n2 = pNode;
                        if (n1 == null) treeViewSystem.Items.Add(n1 = new TreeViewItem { Header = "Node" });
                        n1.Items.Add(pNode);
                        break;
                    case 2:
                        n3 = pNode;
                        if (n1 == null) treeViewSystem.Items.Add(n1 = new TreeViewItem { Header = "Node" });
                        if (n2 == null) n1.Items.Add(n2 = new TreeViewItem { Header = "Node" });
                        n2.Items.Add(pNode);
                        break;
                    case 3:
                        n4 = pNode;
                        if (n1 == null) treeViewSystem.Items.Add(n1 = new TreeViewItem { Header = "Node" });
                        if (n2 == null) n1.Items.Add(n2 = new TreeViewItem { Header = "Node" });
                        if (n3 == null) n2.Items.Add(n3 = new TreeViewItem { Header = "Node" });
                        n3.Items.Add(new TreeViewItem { Header = text });
                        break;
                    case 4:
                        n5 = pNode;
                        n4?.Items.Add(new TreeViewItem { Header = text });
                        break;
                    case 5:
                        n6 = pNode;
                        n5?.Items.Add(new TreeViewItem { Header = text });
                        break;
                    case 6:
                        n6?.Items.Add(new TreeViewItem { Header = text });
                        break;
                    default:
                        treeViewSystem.Items.Add(new TreeViewItem { Header = text });
                        break;
                }
            }

            ExpandItems(treeViewSystem, 3);
        }

        // ── JSON laden / speichern ────────────────────────────────────────────────

        /// <summary>Ersetzt das Assembly-Objekt in einer bestehenden JSON-Datei.</summary>
        public void ReplaceAssembly(string jsonFilePath, SubSystem newAssembly)
        {
            if (!File.Exists(jsonFilePath))
                throw new FileNotFoundException("JSON file not found.", jsonFilePath);

            var rootObj = JObject.Parse(File.ReadAllText(jsonFilePath));
            rootObj["Assembly"] = JObject.FromObject(newAssembly);
            File.WriteAllText(jsonFilePath, rootObj.ToString(Formatting.Indented));
        }

        /// <summary>Speichert die Konfiguration in den Standard-Pfad.</summary>
        private void WriteJsonConfig()
            => WriteJsonConfig(Path.Combine(FileUtils.GlobalConfig.BasePath, "RobiControl.json"));

        /// <summary>Speichert die aktuelle Konfiguration in die angegebene Datei.</summary>
        private void WriteJsonConfig(string jsonFilePath)
        {
            Console.WriteLine($"WriteJsonConfig  {jsonFilePath}");

            var settings = new JsonSerializerSettings
            {
                Formatting        = Formatting.Indented,
                NullValueHandling = NullValueHandling.Ignore,
                ContractResolver  = new DefaultContractResolver()
            };

            if (actSystem != null)
                ReplaceAssembly(actSystem.TemplateName, actSystem);

            if (actRobot != null)
                File.WriteAllText(jsonFilePath, JsonConvert.SerializeObject(actRobot, settings));
        }

        // ── Button-Handler ────────────────────────────────────────────────────────

        private void buttonLoad_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                DefaultExt = ".json",
                FileName   = "RobiControl.json",
                Filter     = "LCAMPConf (*.json)|*.json|Alle Dateien (*.*)|*.*",
                Title      = "Load LCAMP Robot config"
            };

            if (dlg.ShowDialog() == true)
            {
                _loadedFilePath = dlg.FileName;
                OpenFileDialogLoad_FileOk(_loadedFilePath);
            }
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                DefaultExt = ".json",
                Filter     = "LCAMPConf (*.json)|*.json|Alle Dateien (*.*)|*.*",
                Title      = "Save LCAMP Robot config"
            };

            if (dlg.ShowDialog() == true)
            {
                Console.WriteLine("Save: " + dlg.FileName);
                WriteJsonConfig(dlg.FileName);
            }
        }

        private void buttonClear_Click(object sender, RoutedEventArgs e)
        {
            treeViewSystem.Items.Clear();
            rootTreeNode.Items.Clear();
            ConfigurationChanged?.Invoke(("Clear", null, null, null));
        }

        // ── Lade-Logik ────────────────────────────────────────────────────────────

        /// <summary>
        /// Liest eine JSON-Konfigurationsdatei und befüllt den Baum.
        /// Erkennt automatisch ob Robot- oder Assembly/Template-Datei.
        /// </summary>
        private void OpenFileDialogLoad_FileOk(string filePath)
        {
            string readJsonString = File.ReadAllText(filePath);

            try
            {
                JObject jsonObject = JObject.Parse(readJsonString);

                if (jsonObject != null)
                {
                    var aCode = jsonObject["Assembly"];  // vorhanden => Template-Datei

                    if (aCode != null)
                    {
                        // ── Template / Assembly ──────────────────────────────────
                        var aObject  = aCode as JObject ?? JObject.Parse(aCode.ToString());
                        var assembly = aObject.ToObject<SubSystem>();

                        if (assembly != null)
                        {
                            var aNode = new SubSystem($"Assembly: {assembly.Name}");
                            aNode.Components.Add(assembly);
                            RobComponent.GetComponentList<PartDescription>(aObject, aNode);
                            aNode.Type         = "Assembly";
                            aNode.TemplateName = filePath;
                            Robot_configAddBranch(aNode);
                            actSystem = aNode;
                        }
                        else
                        {
                            Console.WriteLine($"Error: no assembly specified in {Path.GetFileNameWithoutExtension(filePath)}");
                        }
                    }
                    else
                    {
                        // ── Roboter-Konfiguration ────────────────────────────────
                        buttonClear_Click(null, null);
                        var newRobot = Newtonsoft.Json.JsonConvert.DeserializeObject<LCAMPRobot>(readJsonString);
                        RobComponent.GetComponentList<PartDescription>(jsonObject, newRobot);
                        actRobot = newRobot;
                        Robot_configAddBranch(actRobot);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: no valid Robot config — {ex}");
            }

            ConfigurationChanged?.Invoke(("Update", filePath, null, actRobot));
        }

        // ── Hilfsmethoden ─────────────────────────────────────────────────────────

        /// <summary>Sucht einen direkten Kindknoten nach seinem Header-Text.</summary>
        private TreeViewItem FindItemByHeader(TreeViewItem parent, string header)
        {
            foreach (TreeViewItem item in parent.Items)
                if (item.Header?.ToString() == header)
                    return item;
            return null;
        }

        /// <summary>Klappt TreeViewItems bis zur angegebenen Tiefe auf.</summary>
        private void ExpandItems(ItemsControl parent, int maxLevel, int currentLevel = 0)
        {
            foreach (var obj in parent.Items)
            {
                if (obj is TreeViewItem item && currentLevel < maxLevel)
                {
                    item.IsExpanded = true;
                    ExpandItems(item, maxLevel, currentLevel + 1);
                }
            }
        }

        /// <summary>
        /// Kompatibilitäts-Brücke: wandelt einen WPF-TreeViewItem in einen
        /// WinForms-TreeNode um, solange RobComponent.SetTreeNode() noch den
        /// WinForms-Typ erwartet. Kann entfernt werden, sobald Core auf WPF portiert ist.
        /// </summary>
        private System.Windows.Forms.TreeNode ToWinFormsNode(TreeViewItem item)
            => new System.Windows.Forms.TreeNode(item.Header?.ToString()) { Tag = item.Tag };
    }
}
