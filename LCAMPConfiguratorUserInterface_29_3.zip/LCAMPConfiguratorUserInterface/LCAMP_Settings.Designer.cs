﻿namespace LCAMPConfigurator.UI
{
    partial class LCAMP_Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxData = new ComboBox();
            comboBoxTemplate = new ComboBox();
            comboBoxOutput = new ComboBox();
            label1 = new Label();
            buttonData = new Button();
            buttonTemplate = new Button();
            buttonOutput = new Button();
            label2 = new Label();
            label3 = new Label();
            labelPackage = new Label();
            buttonSet = new Button();
            buttonCancel = new Button();
            comboBoxBase = new ComboBox();
            label4 = new Label();
            buttonBase = new Button();
            checkBoxData = new CheckBox();
            checkBoxTemplate = new CheckBox();
            checkBoxOutput = new CheckBox();
            folderBrowserDialog = new FolderBrowserDialog();
            label5 = new Label();
            comboBoxWebURL = new ComboBox();
            comboBoxPackage = new ComboBox();
            label6 = new Label();
            buttonPackage = new Button();
            checkBoxPackage = new CheckBox();
            labelFileName = new Label();
            label7 = new Label();
            dataGridViewProperies = new DataGridView();
            openFileDialogConfig = new OpenFileDialog();
            saveFileDialogProject = new SaveFileDialog();
            Key = new DataGridViewTextBoxColumn();
            Value = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridViewProperies).BeginInit();
            SuspendLayout();
            // 
            // comboBoxData
            // 
            comboBoxData.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxData.FormattingEnabled = true;
            comboBoxData.Location = new Point(106, 176);
            comboBoxData.Name = "comboBoxData";
            comboBoxData.Size = new Size(523, 28);
            comboBoxData.TabIndex = 0;
            comboBoxData.SelectedIndexChanged += comboBoxData_SelectedIndexChanged;
            comboBoxData.TextChanged += comboBoxData_TextChanged;
            // 
            // comboBoxTemplate
            // 
            comboBoxTemplate.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxTemplate.FormattingEnabled = true;
            comboBoxTemplate.Location = new Point(106, 232);
            comboBoxTemplate.Name = "comboBoxTemplate";
            comboBoxTemplate.Size = new Size(523, 28);
            comboBoxTemplate.TabIndex = 0;
            comboBoxTemplate.TextChanged += comboBoxTemplate_TextChanged;
            // 
            // comboBoxOutput
            // 
            comboBoxOutput.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxOutput.FormattingEnabled = true;
            comboBoxOutput.Location = new Point(106, 292);
            comboBoxOutput.Name = "comboBoxOutput";
            comboBoxOutput.Size = new Size(523, 28);
            comboBoxOutput.TabIndex = 0;
            comboBoxOutput.TextChanged += comboBoxOutput_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(9, 184);
            label1.Name = "label1";
            label1.Size = new Size(44, 20);
            label1.TabIndex = 1;
            label1.Text = "Data:";
            // 
            // buttonData
            // 
            buttonData.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonData.Location = new Point(631, 177);
            buttonData.Name = "buttonData";
            buttonData.Size = new Size(37, 27);
            buttonData.TabIndex = 2;
            buttonData.Text = "...";
            buttonData.UseVisualStyleBackColor = true;
            buttonData.Click += buttonDir_Click;
            // 
            // buttonTemplate
            // 
            buttonTemplate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonTemplate.Location = new Point(631, 233);
            buttonTemplate.Name = "buttonTemplate";
            buttonTemplate.Size = new Size(37, 27);
            buttonTemplate.TabIndex = 2;
            buttonTemplate.Text = "...";
            buttonTemplate.UseVisualStyleBackColor = true;
            buttonTemplate.Click += buttonDir_Click;
            // 
            // buttonOutput
            // 
            buttonOutput.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonOutput.Location = new Point(631, 293);
            buttonOutput.Name = "buttonOutput";
            buttonOutput.Size = new Size(37, 27);
            buttonOutput.TabIndex = 2;
            buttonOutput.Text = "...";
            buttonOutput.UseVisualStyleBackColor = true;
            buttonOutput.Click += buttonDir_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(5, 240);
            label2.Name = "label2";
            label2.Size = new Size(71, 20);
            label2.TabIndex = 1;
            label2.Text = "Template";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 300);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 1;
            label3.Text = "Output";
            // 
            // labelPackage
            // 
            labelPackage.AutoSize = true;
            labelPackage.Location = new Point(9, 21);
            labelPackage.Name = "labelPackage";
            labelPackage.Size = new Size(63, 20);
            labelPackage.TabIndex = 1;
            labelPackage.Text = "Package";
            // 
            // buttonSet
            // 
            buttonSet.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonSet.DialogResult = DialogResult.OK;
            buttonSet.Location = new Point(609, 624);
            buttonSet.Name = "buttonSet";
            buttonSet.Size = new Size(94, 29);
            buttonSet.TabIndex = 3;
            buttonSet.Text = "set Settings";
            buttonSet.UseVisualStyleBackColor = true;
            buttonSet.Click += buttonSet_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCancel.DialogResult = DialogResult.Cancel;
            buttonCancel.Location = new Point(484, 624);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(94, 29);
            buttonCancel.TabIndex = 3;
            buttonCancel.Text = "Cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            // 
            // comboBoxBase
            // 
            comboBoxBase.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxBase.FormattingEnabled = true;
            comboBoxBase.Location = new Point(106, 127);
            comboBoxBase.Name = "comboBoxBase";
            comboBoxBase.Size = new Size(523, 28);
            comboBoxBase.TabIndex = 0;
            comboBoxBase.TextChanged += comboBoxBase_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 135);
            label4.Name = "label4";
            label4.Size = new Size(71, 20);
            label4.TabIndex = 1;
            label4.Text = "BasePath:";
            // 
            // buttonBase
            // 
            buttonBase.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonBase.Location = new Point(631, 128);
            buttonBase.Name = "buttonBase";
            buttonBase.Size = new Size(37, 27);
            buttonBase.TabIndex = 2;
            buttonBase.Text = "...";
            buttonBase.UseVisualStyleBackColor = true;
            buttonBase.Click += buttonDir_Click;
            // 
            // checkBoxData
            // 
            checkBoxData.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checkBoxData.AutoSize = true;
            checkBoxData.Location = new Point(674, 179);
            checkBoxData.Name = "checkBoxData";
            checkBoxData.Size = new Size(48, 24);
            checkBoxData.TabIndex = 5;
            checkBoxData.Text = "rel";
            checkBoxData.UseVisualStyleBackColor = true;
            checkBoxData.CheckedChanged += checkBoxData_CheckedChanged;
            // 
            // checkBoxTemplate
            // 
            checkBoxTemplate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checkBoxTemplate.AutoSize = true;
            checkBoxTemplate.Location = new Point(674, 235);
            checkBoxTemplate.Name = "checkBoxTemplate";
            checkBoxTemplate.Size = new Size(48, 24);
            checkBoxTemplate.TabIndex = 5;
            checkBoxTemplate.Text = "rel";
            checkBoxTemplate.UseVisualStyleBackColor = true;
            checkBoxTemplate.CheckedChanged += checkBoxTemplate_CheckedChanged;
            // 
            // checkBoxOutput
            // 
            checkBoxOutput.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checkBoxOutput.AutoSize = true;
            checkBoxOutput.Location = new Point(674, 296);
            checkBoxOutput.Name = "checkBoxOutput";
            checkBoxOutput.Size = new Size(48, 24);
            checkBoxOutput.TabIndex = 5;
            checkBoxOutput.Text = "rel";
            checkBoxOutput.UseVisualStyleBackColor = true;
            checkBoxOutput.CheckedChanged += checkBoxOutput_CheckedChanged;
            // 
            // folderBrowserDialog
            // 
            folderBrowserDialog.InitialDirectory = "GlobalConfig.BasePath";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 406);
            label5.Name = "label5";
            label5.Size = new Size(65, 20);
            label5.TabIndex = 1;
            label5.Text = "WebURL";
            // 
            // comboBoxWebURL
            // 
            comboBoxWebURL.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxWebURL.FormattingEnabled = true;
            comboBoxWebURL.Items.AddRange(new object[] { "http://localhost:7077" });
            comboBoxWebURL.Location = new Point(106, 398);
            comboBoxWebURL.Name = "comboBoxWebURL";
            comboBoxWebURL.Size = new Size(523, 28);
            comboBoxWebURL.TabIndex = 0;
            comboBoxWebURL.TextChanged += comboBoxOutput_TextChanged;
            // 
            // comboBoxPackage
            // 
            comboBoxPackage.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxPackage.FormattingEnabled = true;
            comboBoxPackage.Location = new Point(106, 344);
            comboBoxPackage.Name = "comboBoxPackage";
            comboBoxPackage.Size = new Size(523, 28);
            comboBoxPackage.TabIndex = 0;
            comboBoxPackage.TextChanged += comboBoxOutput_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 352);
            label6.Name = "label6";
            label6.Size = new Size(63, 20);
            label6.TabIndex = 1;
            label6.Text = "Package";
            // 
            // buttonPackage
            // 
            buttonPackage.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonPackage.Location = new Point(631, 345);
            buttonPackage.Name = "buttonPackage";
            buttonPackage.Size = new Size(37, 27);
            buttonPackage.TabIndex = 2;
            buttonPackage.Text = "...";
            buttonPackage.UseVisualStyleBackColor = true;
            buttonPackage.Click += buttonDir_Click;
            // 
            // checkBoxPackage
            // 
            checkBoxPackage.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            checkBoxPackage.AutoSize = true;
            checkBoxPackage.Location = new Point(674, 348);
            checkBoxPackage.Name = "checkBoxPackage";
            checkBoxPackage.Size = new Size(48, 24);
            checkBoxPackage.TabIndex = 5;
            checkBoxPackage.Text = "rel";
            checkBoxPackage.UseVisualStyleBackColor = true;
            checkBoxPackage.CheckedChanged += checkBoxOutput_CheckedChanged;
            // 
            // labelFileName
            // 
            labelFileName.AutoSize = true;
            labelFileName.Location = new Point(15, 589);
            labelFileName.Name = "labelFileName";
            labelFileName.Size = new Size(32, 20);
            labelFileName.TabIndex = 1;
            labelFileName.Text = "File";
            labelFileName.DoubleClick += labelFileName_DoubleClick;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(15, 458);
            label7.Name = "label7";
            label7.Size = new Size(71, 20);
            label7.TabIndex = 1;
            label7.Text = "Properies";
            // 
            // dataGridViewProperies
            // 
            dataGridViewProperies.AllowDrop = true;
            dataGridViewProperies.BackgroundColor = SystemColors.ControlLight;
            dataGridViewProperies.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewProperies.Columns.AddRange(new DataGridViewColumn[] { Key, Value });
            dataGridViewProperies.Location = new Point(106, 458);
            dataGridViewProperies.Name = "dataGridViewProperies";
            dataGridViewProperies.RowHeadersWidth = 61;
            dataGridViewProperies.Size = new Size(523, 120);
            dataGridViewProperies.TabIndex = 6;
            // 
            // openFileDialogConfig
            // 
            openFileDialogConfig.DefaultExt = "json";
            openFileDialogConfig.FileName = "openFileDialogConfig";
            openFileDialogConfig.Filter = "Projects|*.json|All files|*.*";
            // 
            // saveFileDialogProject
            // 
            saveFileDialogProject.FileName = "LCAMPConfig.json";
            saveFileDialogProject.Filter = "Projext (*.json)|*.json|All Files|*.*";
            // 
            // Key
            // 
            Key.HeaderText = "Key";
            Key.MinimumWidth = 6;
            Key.Name = "Key";
            Key.Width = 125;
            // 
            // Value
            // 
            Value.HeaderText = "Value";
            Value.MinimumWidth = 6;
            Value.Name = "Value";
            Value.Width = 225;
            // 
            // LCAMP_Settings
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(724, 665);
            Controls.Add(dataGridViewProperies);
            Controls.Add(checkBoxPackage);
            Controls.Add(checkBoxOutput);
            Controls.Add(checkBoxTemplate);
            Controls.Add(checkBoxData);
            Controls.Add(buttonCancel);
            Controls.Add(buttonSet);
            Controls.Add(buttonPackage);
            Controls.Add(buttonOutput);
            Controls.Add(buttonTemplate);
            Controls.Add(buttonBase);
            Controls.Add(buttonData);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(labelFileName);
            Controls.Add(labelPackage);
            Controls.Add(label4);
            Controls.Add(comboBoxWebURL);
            Controls.Add(label1);
            Controls.Add(comboBoxPackage);
            Controls.Add(comboBoxOutput);
            Controls.Add(comboBoxTemplate);
            Controls.Add(comboBoxBase);
            Controls.Add(comboBoxData);
            Name = "LCAMP_Settings";
            Text = "LCAMP Project";
            ((System.ComponentModel.ISupportInitialize)dataGridViewProperies).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxData;
        private System.Windows.Forms.ComboBox comboBoxTemplate;
        private System.Windows.Forms.ComboBox comboBoxOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonData;
        private System.Windows.Forms.Button buttonTemplate;
        private System.Windows.Forms.Button buttonOutput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelPackage;
        private System.Windows.Forms.Button buttonSet;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.ComboBox comboBoxBase;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonBase;
        private System.Windows.Forms.CheckBox checkBoxData;
        private System.Windows.Forms.CheckBox checkBoxTemplate;
        private System.Windows.Forms.CheckBox checkBoxOutput;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxWebURL;
        private ComboBox comboBoxPackage;
        private Label label6;
        private Button buttonPackage;
        private CheckBox checkBoxPackage;
        private Label labelFileName;
        private Label label7;
        private DataGridView dataGridViewProperies;
        private OpenFileDialog openFileDialogConfig;
        private SaveFileDialog saveFileDialogProject;
        private DataGridViewTextBoxColumn Key;
        private DataGridViewTextBoxColumn Value;
    }
}