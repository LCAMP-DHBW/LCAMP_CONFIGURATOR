﻿

#pragma warning disable CA1416


using LCAMPConfigurator.Core;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
//using System.Text.Json.Serialization;
using System.IO.Ports;
using System.Linq;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows.Forms;  // statt System.Windows
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace LCAMPConfigurator.UI
{
    public partial class ConfigurationTreeControl : UserControl
    {

        TreeNode rootTreeNode = new TreeNode("LCAMP Robot");
        public event Action<(string Key, string Value, string mode, RobComponent comp )> ConfigurationChanged;

        public LCAMPRobot actRobot { get; set; }
        public SubSystem actSystem { get; set; }

        public ConfigurationTreeControl()
        {
            InitializeComponent();
        }

        public void Clear()
        {
            treeViewSystem.Nodes.Clear();// deletes Tree Nodes
        }


        private void treeViewSystem_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 && System.IO.Path.GetExtension(files[0]).ToLower() == ".json")
                {
                    e.Effect = System.Windows.Forms.DragDropEffects.Copy;
                }
                else
                {
                    e.Effect = System.Windows.Forms.DragDropEffects.None;
                }
            }
            //e.Handled = true;
        }


        private void treeViewSystem_DragDrop(object sender, DragEventArgs e)
        {

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 && System.IO.Path.GetExtension(files[0]).ToLower() == ".json")
                {
                    openFileDialogLoad.FileName = files[0];
                    OpenFileDialogLoad_FileOk(sender, e);
                    string newTitle = $"LCAMP Configurator - {Path.GetFileName(files[0])}";
                    // Event aufrufen statt direkt setzen
                    ConfigurationChanged?.Invoke(("Title", newTitle, null, null));
                    ConfigurationChanged?.Invoke(("Update", openFileDialogLoad.FileName, null, actRobot));

                }
            }
        }


 



        /// <summary>
        /// Build Branch for Components in Tree Control
        /// </summary>
        /// <param name="componentControl"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public TreeNode Component_configAddBranch(List<RobComponent> componentControl, String name)
        {
            Console.WriteLine($"\tT: {name}");




            if (componentControl.Count > 0)
            {
                TreeNode newTreeNode;
                TreeNode treeNode = new TreeNode(name);

                foreach (RobComponent part in componentControl)
                {
                    String pName = part.Name;
                    part.Parent = name; // Sets Parent to Part
                    if (part is PartDescription p)
                        if (p.Number == null)
                            p.Number = "0";
                        else if ((p.Number != "0") && (p.Number != "1"))
                            pName = $"{part.Name} [{p.Number}]"; // Wenn höhere Anzahl dann im Baum ausgeben
                    if (part.Components.Count == 0)
                    {
                        if (part.Status != "inactive")
                        {
                            treeNode.Nodes.Add(newTreeNode = new TreeNode(pName));
                            newTreeNode.Tag = part;
                            part.SetTreeNode(newTreeNode);
                        }
                    }
                    else if (part.Components.Count > 0)
                    {
                        TreeNode Tnode = Component_configAddBranch(part.Components, pName);
                        //  if (Tnode != null) newTreeNode.Nodes.Add(Tnode);
                        if (Tnode != null)
                        {
                            Tnode.Tag = part;
                            part.SetTreeNode(Tnode);
                            treeNode.Nodes.Add(Tnode);
                        }
                    }

                }
                return treeNode;
            }


            return null;

        }


        /**
         * list all sub componets to console recursiv
         **/
        public void listComponents(RobComponent comp, int level = 1)
        {
            Console.WriteLine(level + ": " + comp.Name);
            foreach (RobComponent part in comp.Components)
            {
                listComponents(part, level + 1);
            }
        }

        /**
         * lists first 5 Level komponents of a Robot Structure
         * shoul List all Substructures recursicely
         **/
        public void listRobotComponents(RobComponent system, int level = 1)
        {
            try
            {
                string smf = new string('\t', level);

                if (system == null)
                {
                    Console.WriteLine($"Mobile Robot or Assembly : nicht definiert");
                    return;
                }
                if(system is LCAMPRobot Rob)
                 Console.WriteLine($"Mobile Robot: {Rob.Name}  Serial: {Rob.SerialNumber} Type: {Rob.Type}");
                else
                    if(system.Components.Count>0)
                  Console.WriteLine($"{smf}{level}  Assembly: {system.Name}  Type: {system.Type}");
                else
                    Console.WriteLine($"{smf}{level}: {system.Name}  Type: {system.Type}");



                foreach (RobComponent part in system.Components)
                {
                    if (part != null)
                    {
                        //Console.WriteLine($"{smf}{level}: {part.Name}");
                        listRobotComponents(part, level + 1);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.ToString());
            }
        }

        /// <summary>
        ///  Build Branch for Components in Tree Control
        /// </summary>
        /// <param name="Rob">Aktuelle Roboter konfiguration</param>
        /// <returns>Kompletter Baum der den Roboter repräsentiert</returns>
        public TreeNode Robot_configAddBranch(SubSystem system)
        {
        //    LCAMPRobot Rob
            if (system == null)
            {
                Console.WriteLine("Error: no Robot or assembly specified in Robot_configAddBranch");
                return null;
            }

            listRobotComponents(system); // lists the configuration in Debug Console

            Console.WriteLine($"Build Tree from {system.Name}");


            if (system.Components.Count > 0)
            {
                TreeNode Tnode = Component_configAddBranch(system.Components, system.Name); // Recursive creation of subnodes for the tree 
                if (Tnode != null)
                {
                    Tnode.Tag = system;
                    system.SetTreeNode(Tnode);
                    // Prüfen ob bereits ein Node mit diesem Namen existiert
                    TreeNode existingNode = FindNodeByName(rootTreeNode, system.Name);
                    if (existingNode != null)
                    {
                        // Existierenden Node überschreiben
                        int index = rootTreeNode.Nodes.IndexOf(existingNode);
                        rootTreeNode.Nodes.RemoveAt(index);
                        rootTreeNode.Nodes.Insert(index, Tnode);

                        // Optional: Logging
                        Console.WriteLine($"TreeNode '{system.Name}' wurde überschrieben.");
                    }
                    else
                    {
                        // Neuen Node hinzufügen
                        rootTreeNode.Nodes.Add(Tnode);

                        // Optional: Logging
                        Console.WriteLine($"Neuer TreeNode '{system.Name}' wurde hinzugefügt.");
                    }
                }
               
            }

            treeViewSystem.Nodes.Clear();
            treeViewSystem.Nodes.Add(rootTreeNode);
            ExpandNodes(treeViewSystem.Nodes, 2);

            return rootTreeNode;
        }


        // Hilfsmethode zum Finden eines Nodes nach Namen
        private TreeNode FindNodeByName(TreeNode parentNode, string nodeName)
        {
            foreach (TreeNode node in parentNode.Nodes)
            {
                if (node.Text == nodeName)
                {
                    return node;
                }
            }
            return null;
        }

        /*
         * fill up nodes of tree with elements
         */
        public void PopulateTreeView(List<Dictionary<string, object>> tableData)
        {
            TreeNode? currentNode = null;
            TreeNode? currentNode1 = null;
            TreeNode? currentNode2 = null;
            TreeNode? currentNode3 = null;
            TreeNode? currentNode4 = null;
            TreeNode? currentNode5 = null;
            TreeNode? currentNode6 = null;

            treeViewSystem.Nodes.Clear();// deletes Tree Nodes

            foreach (Dictionary<string, object> row in tableData)
            {
                string level = row.Values.First() as String; // Die erste Spalte gibt die Knotenebene an

                int nodeLevel = 0;
                if (int.TryParse(level, out nodeLevel))
                {
                    String text = row["Description"] as String; // row[3]["Description"]; // Die zweite Spalte enthält den Text für den Knoten"";         
                    TreeNode pNode = new TreeNode(text);
                    switch (nodeLevel)
                    {
                        case 0:
                            // Erstelle einen neuen Stammknoten
                            currentNode1 = pNode;
                            treeViewSystem.Nodes.Add(pNode);
                            break;
                        case 1:
                            // Füge Kindknoten hinzu
                            currentNode2 = pNode;
                            if (currentNode1 == null) treeViewSystem.Nodes.Add(currentNode1 = new TreeNode("Node"));
                            currentNode1?.Nodes.Add(pNode);
                            break;
                        case 2:
                            // Füge Kindknoten hinzu
                            currentNode3 = pNode;
                            if (currentNode1 == null) treeViewSystem.Nodes.Add(currentNode1 = new TreeNode("Node"));
                            if (currentNode2 == null) currentNode1.Nodes.Add(currentNode2 = new TreeNode("Node"));

                            currentNode2?.Nodes.Add(pNode);
                            break;
                        case 3:
                            // Füge Kindknoten hinzu
                            currentNode4 = pNode;
                            if (currentNode1 == null) treeViewSystem.Nodes.Add(currentNode1 = new TreeNode("Node"));
                            if (currentNode2 == null) currentNode1.Nodes.Add(currentNode2 = new TreeNode("Node"));
                            if (currentNode3 == null) currentNode2.Nodes.Add(currentNode3 = new TreeNode("Node"));


                            currentNode3?.Nodes.Add(text);
                            break;
                        case 4:
                            currentNode5 = pNode;
                            // Füge Kindknoten hinzu
                            currentNode4?.Nodes.Add(text);
                            break;
                        case 5:
                            currentNode6 = pNode;
                            // Füge Kindknoten hinzu
                            currentNode5?.Nodes.Add(text);
                            break;
                        case 6:
                            // Füge Kindknoten hinzu
                            currentNode6?.Nodes.Add(text);
                            break;
                        default:
                            // Füge Kindknoten hinzu
                            if (currentNode == null) treeViewSystem.Nodes.Add(currentNode1 = new TreeNode("Unknown"));
                            currentNode?.Nodes.Add(text);
                            break;




                    }
                }
            }

            ExpandNodes(treeViewSystem.Nodes, 3);// Alle Knoten erweitern
        }


        /// <summary>
        /// Expand Nodes to a certain Level
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="level"></param>
        private void ExpandNodes(TreeNodeCollection nodes, int level)
        {
            ExpandNodes(nodes, 0, level);
        }

        /// <summary>
        ///  Expand Nodes to a certain Level
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="currentLevel"></param>
        /// <param name="maxLevel"></param>
        private void ExpandNodes(TreeNodeCollection nodes, int currentLevel, int maxLevel)
        {
            foreach (TreeNode node in nodes)
            {
                if (currentLevel < maxLevel)
                {
                    node.Expand();
                    if (node.Nodes.Count > 0)
                    {
                        ExpandNodes(node.Nodes, currentLevel + 1, maxLevel);
                    }
                }
            }
        }




        /// <summary>
        ///  läd ein Konfigurationsdatei 
        ///  füllt Liste mit Parts und den Baum
        /// </summary>
        private void ConfigurationTreeLoad()
        {
            string readJsonString = File.ReadAllText(openFileDialogLoad.FileName);


            // JSON-Datei lesen und Inhalt ausgeben
            LCAMPRobot readConfig = System.Text.Json.JsonSerializer.Deserialize<LCAMPRobot>(readJsonString, new JsonSerializerOptions { WriteIndented = true, AllowTrailingCommas = true });

            Console.WriteLine("Action ConfigurationTreeLoad");
            Console.WriteLine("Inhalt der JSON-Datei: " + readConfig);
            foreach (RobComponent part in readConfig.Components)
            {
                Console.WriteLine("\tName: " + part);
            }

            // Parsen des JSON-Strings in ein JsonObject
            JsonNode jsonObject = JsonNode.Parse(readJsonString);

            JsonArray ComponentList = jsonObject["Components"].AsArray();

            treeViewSystem.Nodes.Clear();// deletes Tree Nodes

            if (readConfig != null)
                actRobot = readConfig;
            else
                actRobot = new LCAMPRobot("Mobile Robot") { Id = 1, Parent = "Robot", Type = "Robot" };  // TODO: Handle  Name and ID of the Robot

            rootTreeNode = new TreeNode("LCAMP Robot");
            treeViewSystem.Nodes.Add(rootTreeNode);

            TreeNode newTreeNode;
            JsonArray jComponentList;
            foreach (JsonObject jComponent in ComponentList)
            {

                RobComponent part;

                switch (jComponent["Type"].ToString())
                {
                    case "DriveSystem":
                        part = new DriveSystem(jComponent["Name"].ToString()) { Id = ((int?)jComponent["Id"] ?? 0) };
                        actRobot.Components.Add(part);
                        rootTreeNode.Nodes.Add(newTreeNode = new TreeNode(part.Name));
                        jComponentList = jComponent["Components"].AsArray();

                        foreach (JsonObject jComponent1 in jComponentList)
                        {
                            switch (jComponent1["Type"].ToString())
                            {
                                case "DriveSystem":
                                    RobComponent part1 = new DriveSystem(jComponent1["Name"].ToString()) { Id = ((int?)jComponent1["Id"] ?? 0) };
                                    part.Components.Add(part1);
                                    newTreeNode.Nodes.Add(new TreeNode(part1.Name));

                                    break;
                                case "RobotWheel":
                                    RobComponent part2 = new RobotWheel(jComponent1["Name"].ToString()) { Id = ((int?)jComponent1["Id"] ?? 0) };
                                    part.Components.Add(part2);
                                    newTreeNode.Nodes.Add(new TreeNode(part2.Name));

                                    break;
                            }
                        }
                        // driveControl1.setConfig(part.Components, part.Id);

                        break;
                    case "Devices":
                    case "SensorBox":
                        part = new Sensor(jComponent["Name"].ToString()) { Id = ((int?)jComponent["Id"] ?? 0) };
                        actRobot.Components.Add(part);
                        rootTreeNode.Nodes.Add(newTreeNode = new TreeNode(part.Name));
                        jComponentList = jComponent["Components"].AsArray();

                        foreach (JsonObject jComponent1 in jComponentList)
                        {
                            switch (jComponent1["Type"].ToString())
                            {
                                case "Sensor":
                                    RobComponent part1 = new Sensor(jComponent1["Name"].ToString()) { Id = ((long)jComponent1["Id"]) };
                                    part.Components.Add(part1);
                                    newTreeNode.Nodes.Add(new TreeNode(part1.Name));

                                    break;
                                case "Actor":
                                    RobComponent part2 = new Actor(jComponent1["Name"].ToString()) { Id = ((long)jComponent1["Id"]) };
                                    part.Components.Add(part2);
                                    newTreeNode.Nodes.Add(new TreeNode(part2.Name));

                                    break;

                                case "Device":
                                    RobComponent part3 = new Device(jComponent1["Name"].ToString()) { Id = ((long)jComponent1["Id"]) };
                                    part.Components.Add(part3);
                                    newTreeNode.Nodes.Add(new TreeNode(part3.Name));

                                    break;
                            }
                        }
                        break;

                    case "Controller":
                        part = new Device(jComponent["Name"].ToString()) { Id = ((int?)jComponent["Id"] ?? 0) };
                        actRobot.Components.Add(part);
                        rootTreeNode.Nodes.Add(newTreeNode = new TreeNode(part.Name));
                        jComponentList = jComponent["Components"].AsArray();
                        foreach (JsonObject jComponent1 in jComponentList)
                        {
                            switch (jComponent1["Type"].ToString())
                            {
                                case "Arduino":
                                    RobComponent part1 = new Device(jComponent1["Name"].ToString()) { Id = ((long)jComponent1["Id"]) };
                                    part.Components.Add(part1);
                                    newTreeNode.Nodes.Add(new TreeNode(part1.Name));

                                    break;
                                case "Akku":
                                    RobComponent part2 = new Device(jComponent1["Name"].ToString()) { Id = ((long)jComponent1["Id"]) };
                                    part.Components.Add(part2);
                                    newTreeNode.Nodes.Add(new TreeNode(part2.Name));

                                    break;
                            }
                        }
                        //     controlerControl1.setConfig(part.Components);

                        break;
                    case "MainFrame":
                        part = new Device(jComponent["Name"].ToString()) { Id = ((int)jComponent["Id"]) };
                        actRobot.Components.Add(part);
                        rootTreeNode.Nodes.Add(newTreeNode = new TreeNode(part.Name));
                        jComponentList = jComponent["Components"].AsArray();
                        foreach (JsonObject jComponent1 in jComponentList)
                        {
                            RobComponent part1 = new Device(jComponent1["Name"].ToString()) { Id = ((long)jComponent1["Id"]) };
                            part.Components.Add(part1);
                            newTreeNode.Nodes.Add(new TreeNode(part1.Name));
                        }
                        //   mainFrameControl1.setConfig(part.Components);

                        break;

                }

                Robot_configAddBranch(actRobot);


            }
        }


        public void ReplaceAssembly(string jsonFilePath, SubSystem newAssembly)
        {
            if (!File.Exists(jsonFilePath))
                throw new FileNotFoundException("JSON file not found.", jsonFilePath);

            // Bestehende JSON laden
            var jsonText = File.ReadAllText(jsonFilePath);

            // JSON in JObject parsen
            var rootObject = JObject.Parse(jsonText);

            // Neues Assembly-Objekt in JObject konvertieren
            var newAssemblyObject = JObject.FromObject(newAssembly);

            // Assembly ersetzen oder neu setzen
            rootObject["Assembly"] = newAssemblyObject;

            // JSON formatiert zurückschreiben
            File.WriteAllText(
                jsonFilePath,
                rootObject.ToString(Formatting.Indented)
            );
        }



        /// <summary>
        /// write a Standart File
        /// </summary>
        void WriteJsonConfig()
        {
            WriteJsonConfig(Path.Combine(FileUtils.GlobalConfig.BasePath, "RobiControl.json"));
        }


        /// <summary>
        ///  Erstelt eine TeileListe in Json
        /// ==> Soll später auch auf selectet TreeNodes anwendbar sein
        /// </summary>
        void WriteJsonConfig(String jsonFilePath)
        {
            // JSON-Datei erstellen und Daten speichern

            Console.WriteLine($"WriteJsonConfig  {jsonFilePath}");

            // Einstellungen für Newtonsoft
            var settings = new JsonSerializerSettings
            {
                Formatting = Formatting.Indented,                 // schön eingerückt
                NullValueHandling = NullValueHandling.Ignore,     // Null-Werte unterdrücken
                ContractResolver = new DefaultContractResolver()  // Standard Resolver (für Property-Namen)
            };

            if (actSystem != null)
            {
                ReplaceAssembly(actSystem.TemplateName, actSystem);
            }
            if (actRobot != null)
            {
                string jsonString1 = JsonConvert.SerializeObject(actRobot, settings);
                File.WriteAllText(jsonFilePath, jsonString1);
            }

        }

        // Ereignishandler für den Klick auf eine TreeNode
        private void TreeView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            Console.WriteLine(e.Node.Text);
            // Hier kannst du den Namen der angeklickten TreeNode ausgeben
            if (e.Node.Tag != null)
                if (e.Node.Tag is PartDescription comp)
                {
                    if (comp.Components.Count < 1)
                        Console.WriteLine(comp);// partControl1.InitElements(comp);
                }
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            openFileDialogLoad.ShowDialog();

        }

        /// <summary>
        /// Save Tree to Json"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSave_Click(object sender, EventArgs e)
        {
            saveFileDialogSaveAs.ShowDialog(this);

        }

        private void SaveFileDialogSaveAs_FileOk(object sender, CancelEventArgs e)
        {
            Console.WriteLine("Save:" + saveFileDialogSaveAs.FileName);
            WriteJsonConfig(saveFileDialogSaveAs.FileName);

        }



        private void OpenFileDialogLoad_FileOk(object sender, /*Cancel*/ EventArgs e)
        {
            //  ConfigurationTreeLoad();

            //  actRobot = null;

            string fName= openFileDialogLoad.FileName;

            string readJsonString = File.ReadAllText(fName);
            try
            {
                JObject jsonObject = JObject.Parse(readJsonString);

                if (jsonObject != null)  // File is json Description
                {

                    var cCode = jsonObject["ArduinoCode"];  // search for Arduion Code <= is Template

                    var aCode = jsonObject["Assembly"]; // search for Assembly Code <= is Template

                    if (aCode != null) //<= is Template
                    {
                        // Direkt als JObject verwenden statt doppelt zu parsen
                        var aObject = aCode as JObject ?? JObject.Parse(aCode.ToString());
                        var assembly = aObject.ToObject<SubSystem>();
                        if (assembly != null)
                        {
                            var aNode = new SubSystem($"Assembly: {assembly.Name}");
                            aNode.Components.Add(assembly);
                            RobComponent.GetComponentList<PartDescription>(aObject, aNode);
                            aNode.Type = "Assembly";
                            aNode.TemplateName = fName;
                            Robot_configAddBranch(aNode);
                            actSystem = aNode;
                        }
                        else
                        {    string fileName = Path.GetFileNameWithoutExtension(openFileDialogLoad.FileName);   
                            Console.WriteLine($"Error no assembly specified in {fileName}");
                        }
                    }
                    else // <= is Robot
                    {
                        buttonClear_Click(sender, e);  // Clear existing Robot od Assembly
                        var newRobot = Newtonsoft.Json.JsonConvert.DeserializeObject<LCAMPRobot>(readJsonString);
                        RobComponent.GetComponentList<PartDescription>(jsonObject, newRobot);   // Überladen aller Knoten mit PartDescription
                        actRobot = newRobot;
                        Robot_configAddBranch(actRobot);
                    }


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error no valid Robot:  {ex}");
            }





            string newTitle = $"LCAMP Configurator - {Path.GetFileName(openFileDialogLoad.FileName)}";
            ConfigurationChanged?.Invoke(("Update", openFileDialogLoad.FileName, null, actRobot));  // calls Mainprogram to Update the Robot



        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            treeViewSystem.Nodes.Clear();
            rootTreeNode.Nodes.Clear();
            ConfigurationChanged?.Invoke(("Clear", null, null, null));  // Robot is Cleared

        }
    }
    }

