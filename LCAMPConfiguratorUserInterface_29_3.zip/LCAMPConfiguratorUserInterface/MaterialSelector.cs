﻿

#pragma warning disable CA1416

using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.Windows.Forms;
using System.Drawing;
using LCAMPConfigurator.Core;
using System.Web;
using System.Xml.Linq;


namespace LCAMPConfigurator.UI
{
    public partial class MaterialSelector : Form
    {
        protected List<Materials> materials { get; set; }
        protected Materials _selectedMaterial;
        protected string ExcelFilePath { get; set; }
        public Materials SelectedMaterial
        {
            get { return _selectedMaterial; }
            set
            {
                _selectedMaterial = value;
                SelectdMaterial(_selectedMaterial.Name);
            }
        }

        public MaterialSelector()
        {
            InitializeComponent();
            materials = new List<Materials>();
            FormatMaterialsList();
            LoadSampleData();
            /*
            listViewMaterials.OwnerDraw = true;

            listViewMaterials.DrawItem += (s, e) =>
            {
                if (e.Item.Selected)
                {
                    using (Pen yellowPen = new Pen(Color.Yellow, 2)) // 2px gelbe Linie
                    {
                        // Den Rahmen leicht nach innen verschieben,
                        // damit der Rand vollständig sichtbar bleibt
                        Rectangle rect = e.Bounds;
                        rect.Width -= 1;
                        rect.Height -= 1;

                        e.Graphics.DrawRectangle(yellowPen, rect);
                    }
                }
                else
                {
                    e.DrawDefault = true;
                }
            
            };*/
        }


        private void FormatMaterialsList()
        {
            listViewMaterials.Columns.Add("Name", 150);
            listViewMaterials.Columns.Add("Material", 100);
            listViewMaterials.Columns.Add("Technology", 100);
            listViewMaterials.Columns.Add("ColorName", 120);
            listViewMaterials.Columns.Add("ARGB", 80);
            listViewMaterials.Columns.Add("Reference", 100);

        }


        public void SelectdMaterial(string name)
        {
            Materials found = materials.FirstOrDefault(m => m.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
            if (found != null)
            {
                _selectedMaterial = found;
                UpdateColorPreview();
            }
            else
            {
                if (_selectedMaterial != null)
                    UpdateColorPreview();
            }
        }

        public Materials GetRandomMaterial(string Technologie)
        {
            var matList = GetFilteredMaterials(Technologie);
            // Random-Objekt erzeugen
            Random rnd = new Random();
            // Zufälligen Index bestimmen
            int index = rnd.Next(matList.Count);
            return matList[index];
        }


        public static Color? FindKnownColorFromArgb(Color input)
        {
            int tol = 5;
            foreach (KnownColor known in Enum.GetValues(typeof(KnownColor)))
            {
                Color kc = Color.FromKnownColor(known);
                if (Math.Abs(kc.A - input.A) <= 128 &&
                    Math.Abs(kc.R - input.R) <= tol &&
                    Math.Abs(kc.G - input.G) <= tol &&
                    Math.Abs(kc.B - input.B) <= tol)
                {
                    return kc; //  Übereinstimmung gefunden
                }
            }
            return null; // keine bekannte Farbe
        }


        public void LoadJsonDataList(string fileName)
        {
            // Lesen der Materials-Liste
            string readJson = File.ReadAllText(fileName, Encoding.UTF8);
            LoadSampleData();
            try
            {
                List<Materials> loadedMaterials = JsonConvert.DeserializeObject<List<Materials>>(readJson);
                materials = loadedMaterials;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Load Materials: " + ex.ToString());
            }
             SetFilterList();
             RefreshListView();
        }

        private void SetFilterList() {
            foreach (var mat in materials)
            {
                string Tech= mat.Technology.ToString();
                if (!comboBoxFilter.Items.Contains(Tech))
                {
                    comboBoxFilter.Items.Add(Tech);
                }
            }
                }

        private void LoadSampleData()
        {
            // Beispieldaten laden
            materials.Add(new Materials
            {
                Name = "Stahl Grundplatte",
                MaterialType = "Stahl",
                Technology = "Schweißen",
                Color = new MaterialColor()
                {
                    //  col = FromArgb(128, 128, 128),
                    ColorName = "Grau",
                    ArgbValue = "FF808080"
                }
            });

            materials.Add(new Materials
            {
                Name = "Aluminium Profil",
                MaterialType = "Aluminium",
                Technology = "Extrusion",
                Color = new MaterialColor()
                {
                    //  col = FromArgb(192, 192, 192),
                    ColorName = "Silber",
                    ArgbValue = "FFC0C0C0"
                }
            });

            materials.Add(new Materials
            {
                Name = "Kunststoff Gehäuse",
                MaterialType = "Kunststoff",
                Technology = "Spritzguss",
                Color = new MaterialColor()
                {
                    //  col= FromArgb(255, 0, 0),
                    ColorName = "Rot",
                    ArgbValue = "FFFF0000"
                }
            });

            RefreshListView();
        }

        protected void RefreshListView()
        {
            listViewMaterials.Items.Clear();

            string searchTerm = null;
            if (!string.IsNullOrEmpty(comboBoxFilter.Text))
            {
                searchTerm = comboBoxFilter.Text.ToLower();

            }
            if (!string.IsNullOrEmpty(textBoxSearch.Text))
            {
                searchTerm = textBoxSearch.Text.ToLower();

            }

            var filteredMaterials = GetFilteredMaterials(searchTerm);

            foreach (var material in filteredMaterials)
            {
                var item = new ListViewItem(material.Name);
                item.SubItems.Add(material.MaterialType);
                item.SubItems.Add(material.Technology);
                item.SubItems.Add(material.Color.ColorName);
                item.SubItems.Add(material.Color.ArgbValue);
                item.SubItems.Add(material.Reference);
                item.Tag = material;

                // Hintergrundfarbe setzen

                material.Color.Col = ComponentHelper.HexToColor(material.Color.ArgbValue);
                item.BackColor = material.Color.Col;
                item.ForeColor = GetContrastColor(material.Color.Col);

                listViewMaterials.Items.Add(item);
            }
        }
        private List<Materials> GetFilteredMaterials(string searchTerm)
        {
            if (searchTerm == "all") 
                searchTerm = null;

            var filtered = materials.AsEnumerable();

            // Textsuche
            if (!string.IsNullOrWhiteSpace(searchTerm))
                filtered = filtered.Where(m =>
                    m.Name.ToLower().Contains(searchTerm) ||
                    m.MaterialType.ToLower().Contains(searchTerm) ||
                    m.Technology.ToLower().Contains(searchTerm) ||
                    m.Color.ColorName.ToLower().Contains(searchTerm));


            // Kategorie-Filter
            if (comboBoxFilter.SelectedIndex > 0)
            {
                string filterType = "none";
                filterType = comboBoxFilter.SelectedItem.ToString().ToLower();
                // Hier könnten spezifische Filter implementiert werden
                filtered = filtered.Where(m =>
                   m.Technology.ToLower().Contains(filterType));
            }

            return filtered.ToList();
        }

        private Color GetContrastColor(Color backgroundColor)
        {
            // Berechnung der Helligkeit
            double brightness = (backgroundColor.R * 0.299 + backgroundColor.G * 0.587 + backgroundColor.B * 0.114) / 255;
            return brightness > 0.5 ? Color.Black : Color.White;
        }

        private void ButtonOK_Click(object sender, EventArgs e)
        {
            if (_selectedMaterial == null)
            {
                MessageBox.Show("Bitte wählen Sie ein Material aus.", "Auswahl erforderlich",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // Prüfung bestanden → Dialog schließen
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void ListViewMaterials_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewMaterials.SelectedItems.Count > 0)
            {
                _selectedMaterial = (Materials)listViewMaterials.SelectedItems[0].Tag;
                UpdateColorPreview();
                labelStatus.Text = $"{_selectedMaterial.Name} selected!";

            }
            else
            {
                _selectedMaterial = null;
                UpdateColorPreview();
            }
        }
        private void UpdateColorPreview()
        {
            if (_selectedMaterial != null)
            {
                panelColorPreview.BackColor = _selectedMaterial.Color.Col;
                lableColerInfo.Text = $"Name: {_selectedMaterial.Name}\n" +
                                    $"Material: {_selectedMaterial.MaterialType}\n" +
                                    $"Technologie: {_selectedMaterial.Technology}\n" +
                                    $"Farbe: {_selectedMaterial.Color.ColorName}\n" +
                                    $"ARGB: {_selectedMaterial.Color.ArgbValue}\n" +
                                    $"RGB: A= {_selectedMaterial.Color.Col.A}, R={_selectedMaterial.Color.Col.R}, G={_selectedMaterial.Color.Col.G}, B={_selectedMaterial.Color.Col.B}\n" +
                                    $"Reference: {_selectedMaterial.Reference}\n";
            }
            else
            {
                panelColorPreview.BackColor = Color.White;
                lableColerInfo.Text = "Kein Material ausgewählt";
            }
        }



        private void ButtonUpdateExcel_Click(object sender, EventArgs e)
        {
            UpdateExcel(ExcelFilePath);
        }
        protected virtual void UpdateExcel(string ExcelFilePath)
        {
        }




        protected virtual void LoadFromExcel(string filePath)
        {
            Console.WriteLine("not implemented here");
        }

        private void comboBoxFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected= comboBoxFilter.SelectedIndex;
            Console.WriteLine($"Set Filter to : ");
            RefreshListView();
        }
    }
}
