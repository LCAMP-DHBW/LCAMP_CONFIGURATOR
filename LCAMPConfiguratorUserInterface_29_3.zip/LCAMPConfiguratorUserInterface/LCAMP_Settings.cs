﻿
#pragma warning disable CA1416

using LCAMPConfigurator.Core;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace LCAMPConfigurator.UI
{
    /// <summary>
    /// Settings for LCAMP System
    /// </summary>
    public partial class LCAMP_Settings : Form
    {

        private const string REGISTRY_KEY = @"SOFTWARE\LCAMP";
        private const string VALUE_NAME = "LCAMPConfigPath";

        public string docPath { get { return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments); } }
        public string docPathDesktop { get { return Environment.GetFolderPath(Environment.SpecialFolder.Desktop); } }
        public string currentDirectory = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory).FullName;
        public string rootDirectory = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory).Parent.Parent.Parent.FullName;
        LCAMPConfig _globalConfig;
        public LCAMPConfig GlobalConfig { get { return _globalConfig; } }
        LCAMPConfig tempConfig;
        public LCAMP_Settings()
        {
            InitializeComponent();
            _globalConfig = ConfigHelper.GetDefaultConfig();
            tempConfig = new LCAMPConfig
            {
                BasePath = _globalConfig.BasePath,
                DataPath = _globalConfig.DataPath,
                OutputPath = _globalConfig.OutputPath,
                TemplatePath = _globalConfig.TemplatePath,
                PackagePath = _globalConfig.PackagePath,
                WebURL = _globalConfig.WebURL,
            };

            UpdateList(tempConfig.BasePath);
            comboBoxBase.Text = tempConfig.BasePath;
            labelFileName.Text = ConfigHelper.GetConfigFileName();
            dataGridViewProperies.DataSource = _globalConfig.Data;

        }

        private void UpdateList(string newPath)
        {
            labelPackage.Text = $"Package: {tempConfig.BasePath}\n\t{rootDirectory}\n\t{docPath}\n\t{docPathDesktop}";
            if (!newPath.Equals(tempConfig.BasePath))
            {
                comboBoxBase.Text = newPath;
                comboBoxBase.Items.Clear();
                comboBoxBase.Items.Add(newPath);
                comboBoxBase.Items.Add(docPath);
                comboBoxBase.Items.Add(rootDirectory);
                comboBoxBase.Items.Add(docPathDesktop);
                comboBoxBase.Items.Add(currentDirectory);
                tempConfig.BasePath = newPath;
            }
            try
            {

                tempConfig.DataPath = Path.Combine(tempConfig.BasePath, "Daten");
                comboBoxData.Text = tempConfig.DataPath;
                comboBoxData.Items.Clear();
                comboBoxData.Items.Add(tempConfig.DataPath);
                comboBoxData.Items.Add(rootDirectory);
                comboBoxData.Items.Add(Path.Combine(tempConfig.BasePath, "Daten"));
                comboBoxData.Items.Add(Path.Combine(tempConfig.BasePath, tempConfig.DataPath));
                comboBoxData.Items.Add("Daten");

                tempConfig.TemplatePath = Path.Combine(tempConfig.BasePath, "Templates");
                comboBoxTemplate.Text = tempConfig.TemplatePath;
                comboBoxTemplate.Items.Clear();
                comboBoxTemplate.Items.Add(Path.Combine(tempConfig.BasePath, "Templates"));
                comboBoxTemplate.Items.Add(Path.Combine(tempConfig.DataPath, "Templates"));
                comboBoxTemplate.Items.Add(rootDirectory);
                comboBoxTemplate.Items.Add(Path.Combine(tempConfig.BasePath, tempConfig.TemplatePath));
                comboBoxTemplate.Items.Add("Templates");

                tempConfig.OutputPath = Path.Combine(tempConfig.BasePath, "Output");

                comboBoxOutput.Text = tempConfig.OutputPath;
                comboBoxOutput.Items.Clear();
                comboBoxOutput.Items.Add(Path.Combine(tempConfig.BasePath, "Output"));
                comboBoxOutput.Items.Add(Path.Combine(tempConfig.DataPath, "Output"));
                comboBoxOutput.Items.Add(Path.Combine(tempConfig.BasePath, tempConfig.OutputPath));
                comboBoxOutput.Items.Add("Output");

                comboBoxPackage.Text = tempConfig.PackagePath;
                comboBoxPackage.Items.Clear();
                comboBoxPackage.Items.Add(Path.Combine(tempConfig.OutputPath, "Package"));
                comboBoxPackage.Items.Add(Path.Combine(tempConfig.DataPath, "Package"));
                comboBoxPackage.Items.Add(Path.Combine(tempConfig.BasePath, tempConfig.PackagePath));
                comboBoxPackage.Items.Add("Package");


                comboBoxWebURL.Text = tempConfig.WebURL;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Path does not ework: " + ex);
            }
        }


        private void buttonSet_Click(object sender, EventArgs e)
        {
            bool fail = false;
            if (Path.Exists(comboBoxBase.Text))
                _globalConfig.BasePath = comboBoxBase.Text;
            else fail = true;

            if (checkBoxData.Checked)
                if (!Path.IsPathRooted(comboBoxData.Text))
                    comboBoxData.Text = Path.GetRelativePath(_globalConfig.BasePath, comboBoxData.Text);
            if (Path.Exists(comboBoxData.Text))
                _globalConfig.DataPath = comboBoxData.Text;
            else fail = true;

            if (checkBoxTemplate.Checked)
                if (!Path.IsPathRooted(comboBoxTemplate.Text))
                    checkBoxTemplate.Text = Path.GetRelativePath(_globalConfig.BasePath, comboBoxTemplate.Text);
            if (Path.Exists(comboBoxTemplate.Text))
                _globalConfig.TemplatePath = comboBoxTemplate.Text;
            else fail = true;

            if (checkBoxOutput.Checked)
                if (!Path.IsPathRooted(comboBoxOutput.Text))
                    comboBoxOutput.Text = Path.GetRelativePath(_globalConfig.BasePath, comboBoxOutput.Text);
            if (Path.Exists(comboBoxOutput.Text))
                _globalConfig.OutputPath = comboBoxOutput.Text;
            else fail = true;

            if (checkBoxPackage.Checked)
                if (!Path.IsPathRooted(comboBoxPackage.Text))
                    comboBoxPackage.Text = Path.GetRelativePath(_globalConfig.BasePath, comboBoxPackage.Text);
            if (Path.Exists(comboBoxPackage.Text))
                _globalConfig.PackagePath = comboBoxPackage.Text;
            else fail = true;


            if (!string.IsNullOrWhiteSpace(comboBoxWebURL.Text))
            {
                if (_globalConfig.WebURL != comboBoxWebURL.Text)
                    _globalConfig.WebRestart = true;
                else
                    _globalConfig.WebRestart = false;
                _globalConfig.WebURL = comboBoxWebURL.Text;
            }

            Console.WriteLine($"Save Settings");
            if (fail)
            {
                Console.WriteLine($"Error FilePath does not exist");
                return;
            }
            ConfigHelper.SaveDefaultConfig(_globalConfig);

        }

        private void buttonDir_Click(object sender, EventArgs e)
        {
            Button? b = (sender as Button);
            folderBrowserDialog.ShowDialog(this);
            switch (b.Name)
            {
                case "buttonBase":
                    comboBoxBase.Text = folderBrowserDialog.SelectedPath;
                    tempConfig.BasePath = comboBoxBase.Text;
                    // UpdateList();
                    break;
                case "buttonData":
                    if (checkBoxData.Checked)
                        comboBoxData.Text = Path.GetRelativePath(tempConfig.BasePath, folderBrowserDialog.SelectedPath);
                    else
                        comboBoxData.Text = folderBrowserDialog.SelectedPath;


                    checkValid(comboBoxData, checkBoxData, comboBoxData.Text);
                    break;

                case "buttonTemplate":
                    if (checkBoxTemplate.Checked)
                        comboBoxTemplate.Text = Path.GetRelativePath(tempConfig.BasePath, folderBrowserDialog.SelectedPath);
                    else
                        comboBoxTemplate.Text = folderBrowserDialog.SelectedPath;

                    checkValid(comboBoxTemplate, checkBoxTemplate, comboBoxTemplate.Text);
                    break;

                case "buttonPackage":
                    if (checkBoxPackage.Checked)
                        comboBoxPackage.Text = Path.GetRelativePath(tempConfig.BasePath, folderBrowserDialog.SelectedPath);
                    else
                        comboBoxPackage.Text = folderBrowserDialog.SelectedPath;

                    checkValid(comboBoxPackage, checkBoxPackage,  comboBoxPackage.Text);
                    break;


                case "buttonOutput":
                    if (checkBoxOutput.Checked)
                        comboBoxOutput.Text = Path.GetRelativePath(tempConfig.BasePath, folderBrowserDialog.SelectedPath);
                    else
                        comboBoxOutput.Text = folderBrowserDialog.SelectedPath;
                    checkValid(comboBoxOutput, checkBoxOutput,  comboBoxOutput.Text);
                    break;
            }
            Console.WriteLine($"Data Click");
        }

        private bool checkValid(ComboBox cBox, CheckBox check,  string fName)
        {
            if (check != null)
            {
                if (Path.IsPathRooted(fName))
                {
                    ;//    check.Checked = false;  // if Not Rooted Path is Relative
                }
                else
                {
                    fName = Path.Combine(comboBoxBase.Text, fName);
               //     check.Checked = true;  // if Not Rooted Path is Relative
                }
            }


            if (!Path.Exists(fName))
            {
                cBox.BackColor = Color.LightSalmon;
                return false;

            }
            else
                cBox.BackColor = SystemColors.Window;
            return true;
        }



        private void comboBoxData_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fName = comboBoxData.Text;
            if (checkBoxData.Checked)
            {
                fName = Path.Combine(tempConfig.BasePath, fName);
            }

            if (Path.IsPathRooted(comboBoxData.Text))
                checkBoxData.Checked = false;


            checkValid(comboBoxData, checkBoxData, fName);

        }



        private void comboBoxOutput_TextChanged(object sender, EventArgs e)
        {
            string fName = comboBoxOutput.Text;
            if (checkBoxOutput.Checked)
            {
                fName = Path.Combine(tempConfig.BasePath, fName);
            }

            checkValid(comboBoxOutput, checkBoxOutput,  fName);

            if (Path.IsPathRooted(comboBoxOutput.Text))
                checkBoxOutput.Checked = false;


        }
        private void checkBoxOutput_CheckedChanged(object sender, EventArgs e)
        {

            string fName = comboBoxOutput.Text;
            if (checkBoxOutput.Checked)
                comboBoxOutput.Text = Path.GetRelativePath(tempConfig.BasePath, fName);
            else
                comboBoxOutput.Text = Path.Combine(tempConfig.BasePath, fName);
            checkValid(comboBoxOutput, checkBoxOutput, comboBoxOutput.Text);




        }

        private void checkBoxPackage_CheckedChanged(object sender, EventArgs e)
        {

            string fName = comboBoxPackage.Text;
            if (checkBoxPackage.Checked)
                comboBoxPackage.Text = Path.GetRelativePath(tempConfig.BasePath, fName);
            else
                comboBoxPackage.Text = Path.Combine(tempConfig.BasePath, fName);
            checkValid(comboBoxPackage, checkBoxPackage, comboBoxPackage.Text);




        }


        private void comboBoxTemplate_TextChanged(object sender, EventArgs e)
        {
            string fName = comboBoxTemplate.Text;
            if (checkBoxTemplate.Checked)
            {
                fName = Path.Combine(_globalConfig.BasePath, fName);
            }
            checkValid(comboBoxTemplate, checkBoxTemplate, comboBoxTemplate.Text);

            if (Path.IsPathRooted(comboBoxTemplate.Text))
                checkBoxTemplate.Checked = false;


        }

        private void checkBoxTemplate_CheckedChanged(object sender, EventArgs e)
        {
            string fName = comboBoxTemplate.Text;
            if (checkBoxTemplate.Checked )
            {
                comboBoxTemplate.Text = Path.GetRelativePath(_globalConfig.BasePath, fName);
                checkValid(comboBoxTemplate, checkBoxTemplate, Path.Combine(_globalConfig.BasePath, comboBoxTemplate.Text));

            }
            if (Path.IsPathRooted(comboBoxTemplate.Text))
                checkBoxTemplate.Checked = false;

            checkValid(comboBoxTemplate, checkBoxTemplate, fName);

        }


        private void comboBoxData_TextChanged(object sender, EventArgs e)
        {
            string fName = comboBoxData.Text;
            if (checkBoxData.Checked)
            {
                fName = Path.Combine(_globalConfig.BasePath, fName);
                checkValid(comboBoxData, checkBoxData, Path.Combine(_globalConfig.BasePath, comboBoxData.Text));

            }

            if (Path.IsPathRooted(comboBoxData.Text))
                checkBoxData.Checked = false;

            checkValid(comboBoxData, checkBoxData, fName);


        }
        private void checkBoxData_CheckedChanged(object sender, EventArgs e)
        {
            string fName = comboBoxData.Text;
            if (checkBoxData.Checked)
            {
                comboBoxData.Text = Path.GetRelativePath(_globalConfig.BasePath, fName);
                checkValid(comboBoxData, checkBoxData, Path.Combine(_globalConfig.BasePath, comboBoxData.Text));
            }
            else
            {
                comboBoxData.Text = Path.Combine(_globalConfig.BasePath, fName);
                checkValid(comboBoxData, checkBoxData, comboBoxData.Text);
            }

        }



        private void comboBoxBase_TextChanged(object sender, EventArgs e)
        {
            if (checkValid(comboBoxBase,null , comboBoxBase.Text))
            {
                UpdateList(comboBoxBase.Text);
                //        tempConfig.BasePath = comboBoxBase.Text;
            }

        }





        /// <summary>
        /// Schreibt den JSON-Pfad in die Registry, falls er nicht bereits existiert oder sich geändert hat
        /// </summary>
        /// <param name="jsonFilePath">Pfad zur JSON-Einstellungsdatei</param>
        /// <returns>True wenn erfolgreich, False wenn Fehler aufgetreten</returns>
        public static bool SetJsonConfigPath(string jsonFilePath)
        {
            try
            {
                // Prüfen ob die JSON-Datei existiert
                if (!File.Exists(jsonFilePath))
                {
                    Console.WriteLine($"Error: JSON-Datei '{jsonFilePath}' existiert nicht.");
                    return false;
                }

                // Registry-Key öffnen oder erstellen
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(REGISTRY_KEY))
                {
                    if (key == null)
                    {
                        Console.WriteLine("Error: Registry-Key konnte nicht erstellt werden.");
                        return false;
                    }

                    // Prüfen ob bereits ein Wert existiert
                    string existingPath = key.GetValue(VALUE_NAME) as string;

                    if (!string.IsNullOrEmpty(existingPath))
                    {
                        // Prüfen ob der existierende Pfad noch gültig ist
                        if (File.Exists(existingPath) && existingPath.Equals(jsonFilePath, StringComparison.OrdinalIgnoreCase))
                        {
                            Console.WriteLine($"JSON-Konfigurationspfad ist bereits korrekt in der Registry eingetragen: {existingPath}");
                            return true;
                        }
                        else
                        {
                            Console.WriteLine($"Existierender Pfad wird aktualisiert von '{existingPath}' zu '{jsonFilePath}'");
                        }
                    }

                    // Neuen oder aktualisierten Pfad in Registry schreiben
                    key.SetValue(VALUE_NAME, jsonFilePath, RegistryValueKind.String);
                    Console.WriteLine($"JSON-Konfigurationspfad erfolgreich in Registry eingetragen: {jsonFilePath}");
                    return true;
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"Fehler: Keine Berechtigung für Registry-Zugriff - {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unerwarteter Fehler: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Liest den JSON-Pfad aus der Registry
        /// </summary>
        /// <returns>Pfad zur JSON-Datei oder null wenn nicht gefunden</returns>
        public static string GetJsonConfigPath()
        {
            try
            {
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(REGISTRY_KEY))
                {
                    if (key != null)
                    {
                        string? path = key.GetValue(VALUE_NAME) as string;

                        // Zusätzlich prüfen ob die Datei noch existiert
                        if (!string.IsNullOrEmpty(path) && File.Exists(path))
                        {
                            return path;
                        }
                        else if (!string.IsNullOrEmpty(path))
                        {
                            Console.WriteLine($"Warning: In Registry gespeicherter Pfad existiert nicht mehr: {path}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error beim Lesen aus Registry: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Entfernt den JSON-Pfad aus der Registry
        /// </summary>
        /// <returns>True wenn erfolgreich entfernt</returns>
        public static bool RemoveJsonConfigPath()
        {
            try
            {
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(REGISTRY_KEY, true))
                {
                    if (key != null)
                    {
                        key.DeleteValue(VALUE_NAME, false);
                        Console.WriteLine("JSON-Konfigurationspfad aus Registry entfernt.");
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error beim Entfernen aus Registry: {ex.Message}");
            }

            return false;
        }

        /// <summary>
        /// Prüft ob ein Registry-Eintrag für den JSON-Pfad existiert
        /// </summary>
        /// <returns>True wenn Eintrag vorhanden</returns>
        public static bool HasJsonConfigPath()
        {
            try
            {
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(REGISTRY_KEY))
                {
                    if (key != null)
                    {
                        return key.GetValue(VALUE_NAME) != null;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error beim Prüfen der Registry: {ex.Message}");
            }

            return false;
        }

        private void labelFileName_DoubleClick(object sender, EventArgs e)
        {
            Console.WriteLine($"File Path for Config File: {labelFileName.Text}");
            if (saveFileDialogProject.ShowDialog(this) == DialogResult.OK)
            {
                Console.WriteLine($"New File Path for Config File: {openFileDialogConfig.FileName}");
            
                ConfigHelper.SaveDefaultConfig(_globalConfig, saveFileDialogProject.FileName);
            }

        }

        
    }

}





