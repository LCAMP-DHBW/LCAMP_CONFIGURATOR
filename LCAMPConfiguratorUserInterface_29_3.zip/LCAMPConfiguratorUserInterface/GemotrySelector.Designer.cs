﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LCAMPConfigurator.UI
{
    partial class GemotrySelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelBoundingBox = new Label();
            groupBoxPos = new GroupBox();
            labelZ = new Label();
            labelY = new Label();
            labelX = new Label();
            numericUpDownZ = new NumericUpDown();
            numericUpDownY = new NumericUpDown();
            numericUpDownX = new NumericUpDown();
            groupBoxRot = new GroupBox();
            labelRotZ = new Label();
            labelRotY = new Label();
            labelRotX = new Label();
            numericUpDownRotZ = new NumericUpDown();
            numericUpDownRotY = new NumericUpDown();
            numericUpDownRotX = new NumericUpDown();
            buttonCancel = new Button();
            buttonOK = new Button();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            buttonSetBox = new Button();
            groupBox = new GroupBox();
            radioButtonCylinder = new RadioButton();
            radioButtonMesh = new RadioButton();
            radioButtonSpere = new RadioButton();
            radioButton_box = new RadioButton();
            label_r = new Label();
            label_h = new Label();
            label_w = new Label();
            numericUpDown_r = new NumericUpDown();
            label_l = new Label();
            numericUpDown_h = new NumericUpDown();
            numericUpDown_w = new NumericUpDown();
            numericUpDown_l = new NumericUpDown();
            label1 = new Label();
            numericUpDown_ox = new NumericUpDown();
            numericUpDown_oy = new NumericUpDown();
            label2 = new Label();
            label3 = new Label();
            numericUpDown_oz = new NumericUpDown();
            groupBoxPos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownX).BeginInit();
            groupBoxRot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownRotZ).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownRotY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownRotX).BeginInit();
            groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_r).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_h).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_w).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_l).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_ox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_oy).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_oz).BeginInit();
            SuspendLayout();
            // 
            // labelBoundingBox
            // 
            labelBoundingBox.AutoSize = true;
            labelBoundingBox.Location = new Point(22, 196);
            labelBoundingBox.Name = "labelBoundingBox";
            labelBoundingBox.Size = new Size(98, 20);
            labelBoundingBox.TabIndex = 13;
            labelBoundingBox.Text = "BoundingBox";
            // 
            // groupBoxPos
            // 
            groupBoxPos.Controls.Add(labelZ);
            groupBoxPos.Controls.Add(labelY);
            groupBoxPos.Controls.Add(labelX);
            groupBoxPos.Controls.Add(numericUpDownZ);
            groupBoxPos.Controls.Add(numericUpDownY);
            groupBoxPos.Controls.Add(numericUpDownX);
            groupBoxPos.Location = new Point(22, 12);
            groupBoxPos.Name = "groupBoxPos";
            groupBoxPos.Size = new Size(197, 170);
            groupBoxPos.TabIndex = 11;
            groupBoxPos.TabStop = false;
            groupBoxPos.Text = "Position";
            // 
            // labelZ
            // 
            labelZ.AutoSize = true;
            labelZ.Location = new Point(12, 117);
            labelZ.Name = "labelZ";
            labelZ.Size = new Size(56, 20);
            labelZ.TabIndex = 6;
            labelZ.Text = "Trans Z";
            // 
            // labelY
            // 
            labelY.AutoSize = true;
            labelY.Location = new Point(12, 84);
            labelY.Name = "labelY";
            labelY.Size = new Size(55, 20);
            labelY.TabIndex = 7;
            labelY.Text = "Trans Y";
            // 
            // labelX
            // 
            labelX.AutoSize = true;
            labelX.Location = new Point(12, 51);
            labelX.Name = "labelX";
            labelX.Size = new Size(56, 20);
            labelX.TabIndex = 8;
            labelX.Text = "Trans X";
            // 
            // numericUpDownZ
            // 
            numericUpDownZ.DecimalPlaces = 2;
            numericUpDownZ.Location = new Point(84, 115);
            numericUpDownZ.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDownZ.Minimum = new decimal(new int[] { 300, 0, 0, int.MinValue });
            numericUpDownZ.Name = "numericUpDownZ";
            numericUpDownZ.Size = new Size(83, 27);
            numericUpDownZ.TabIndex = 3;
            // 
            // numericUpDownY
            // 
            numericUpDownY.DecimalPlaces = 2;
            numericUpDownY.Location = new Point(84, 82);
            numericUpDownY.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDownY.Minimum = new decimal(new int[] { 300, 0, 0, int.MinValue });
            numericUpDownY.Name = "numericUpDownY";
            numericUpDownY.Size = new Size(83, 27);
            numericUpDownY.TabIndex = 4;
            // 
            // numericUpDownX
            // 
            numericUpDownX.DecimalPlaces = 2;
            numericUpDownX.Location = new Point(84, 49);
            numericUpDownX.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDownX.Minimum = new decimal(new int[] { 300, 0, 0, int.MinValue });
            numericUpDownX.Name = "numericUpDownX";
            numericUpDownX.Size = new Size(83, 27);
            numericUpDownX.TabIndex = 5;
            // 
            // groupBoxRot
            // 
            groupBoxRot.Controls.Add(labelRotZ);
            groupBoxRot.Controls.Add(labelRotY);
            groupBoxRot.Controls.Add(labelRotX);
            groupBoxRot.Controls.Add(numericUpDownRotZ);
            groupBoxRot.Controls.Add(numericUpDownRotY);
            groupBoxRot.Controls.Add(numericUpDownRotX);
            groupBoxRot.Location = new Point(272, 12);
            groupBoxRot.Name = "groupBoxRot";
            groupBoxRot.Size = new Size(195, 170);
            groupBoxRot.TabIndex = 10;
            groupBoxRot.TabStop = false;
            groupBoxRot.Text = "Rotation";
            // 
            // labelRotZ
            // 
            labelRotZ.AutoSize = true;
            labelRotZ.Location = new Point(18, 122);
            labelRotZ.Name = "labelRotZ";
            labelRotZ.Size = new Size(66, 20);
            labelRotZ.TabIndex = 6;
            labelRotZ.Text = "Rotate Z";
            // 
            // labelRotY
            // 
            labelRotY.AutoSize = true;
            labelRotY.Location = new Point(18, 89);
            labelRotY.Name = "labelRotY";
            labelRotY.Size = new Size(65, 20);
            labelRotY.TabIndex = 7;
            labelRotY.Text = "Rotate Y";
            // 
            // labelRotX
            // 
            labelRotX.AutoSize = true;
            labelRotX.Location = new Point(18, 56);
            labelRotX.Name = "labelRotX";
            labelRotX.Size = new Size(66, 20);
            labelRotX.TabIndex = 8;
            labelRotX.Text = "Rotate X";
            // 
            // numericUpDownRotZ
            // 
            numericUpDownRotZ.DecimalPlaces = 1;
            numericUpDownRotZ.Increment = new decimal(new int[] { 90, 0, 0, 0 });
            numericUpDownRotZ.Location = new Point(90, 120);
            numericUpDownRotZ.Maximum = new decimal(new int[] { 180, 0, 0, 0 });
            numericUpDownRotZ.Minimum = new decimal(new int[] { 180, 0, 0, int.MinValue });
            numericUpDownRotZ.Name = "numericUpDownRotZ";
            numericUpDownRotZ.Size = new Size(83, 27);
            numericUpDownRotZ.TabIndex = 3;
            // 
            // numericUpDownRotY
            // 
            numericUpDownRotY.DecimalPlaces = 1;
            numericUpDownRotY.Increment = new decimal(new int[] { 90, 0, 0, 0 });
            numericUpDownRotY.Location = new Point(90, 87);
            numericUpDownRotY.Maximum = new decimal(new int[] { 180, 0, 0, 0 });
            numericUpDownRotY.Minimum = new decimal(new int[] { 180, 0, 0, int.MinValue });
            numericUpDownRotY.Name = "numericUpDownRotY";
            numericUpDownRotY.Size = new Size(83, 27);
            numericUpDownRotY.TabIndex = 4;
            // 
            // numericUpDownRotX
            // 
            numericUpDownRotX.DecimalPlaces = 1;
            numericUpDownRotX.Increment = new decimal(new int[] { 90, 0, 0, 0 });
            numericUpDownRotX.Location = new Point(90, 54);
            numericUpDownRotX.Maximum = new decimal(new int[] { 180, 0, 0, 0 });
            numericUpDownRotX.Minimum = new decimal(new int[] { 180, 0, 0, int.MinValue });
            numericUpDownRotX.Name = "numericUpDownRotX";
            numericUpDownRotX.Size = new Size(83, 27);
            numericUpDownRotX.TabIndex = 5;
            // 
            // buttonCancel
            // 
            buttonCancel.DialogResult = DialogResult.Cancel;
            buttonCancel.Location = new Point(199, 300);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(94, 45);
            buttonCancel.TabIndex = 7;
            buttonCancel.Text = "cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            // 
            // buttonOK
            // 
            buttonOK.DialogResult = DialogResult.OK;
            buttonOK.Location = new Point(345, 300);
            buttonOK.Name = "buttonOK";
            buttonOK.Size = new Size(122, 45);
            buttonOK.TabIndex = 9;
            buttonOK.Text = "Set Geometry";
            buttonOK.UseVisualStyleBackColor = true;
            buttonOK.Click += buttonOK_Click;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(34, 275);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(63, 24);
            radioButton1.TabIndex = 7;
            radioButton1.TabStop = true;
            radioButton1.Text = "fixed";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(34, 305);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(94, 24);
            radioButton2.TabIndex = 8;
            radioButton2.TabStop = true;
            radioButton2.Text = "continous";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // buttonSetBox
            // 
            buttonSetBox.Location = new Point(279, 209);
            buttonSetBox.Name = "buttonSetBox";
            buttonSetBox.Size = new Size(188, 29);
            buttonSetBox.TabIndex = 9;
            buttonSetBox.Text = "Set Box";
            buttonSetBox.UseVisualStyleBackColor = true;
            buttonSetBox.Click += buttonSetBox_Click;
            // 
            // groupBox
            // 
            groupBox.Controls.Add(radioButtonCylinder);
            groupBox.Controls.Add(radioButtonMesh);
            groupBox.Controls.Add(radioButtonSpere);
            groupBox.Controls.Add(radioButton_box);
            groupBox.Controls.Add(label3);
            groupBox.Controls.Add(label2);
            groupBox.Controls.Add(label1);
            groupBox.Controls.Add(label_r);
            groupBox.Controls.Add(label_h);
            groupBox.Controls.Add(label_w);
            groupBox.Controls.Add(numericUpDown_oz);
            groupBox.Controls.Add(numericUpDown_oy);
            groupBox.Controls.Add(numericUpDown_ox);
            groupBox.Controls.Add(numericUpDown_r);
            groupBox.Controls.Add(label_l);
            groupBox.Controls.Add(numericUpDown_h);
            groupBox.Controls.Add(numericUpDown_w);
            groupBox.Controls.Add(numericUpDown_l);
            groupBox.Location = new Point(524, 12);
            groupBox.Name = "groupBox";
            groupBox.Size = new Size(199, 372);
            groupBox.TabIndex = 14;
            groupBox.TabStop = false;
            groupBox.Text = "BoundingBox";
            groupBox.Visible = false;
            // 
            // radioButtonCylinder
            // 
            radioButtonCylinder.AutoSize = true;
            radioButtonCylinder.Location = new Point(90, 309);
            radioButtonCylinder.Name = "radioButtonCylinder";
            radioButtonCylinder.Size = new Size(84, 24);
            radioButtonCylinder.TabIndex = 9;
            radioButtonCylinder.TabStop = true;
            radioButtonCylinder.Text = "Cylinder";
            radioButtonCylinder.UseVisualStyleBackColor = true;
            radioButtonCylinder.CheckedChanged += radioButtonCylinder_CheckedChanged;
            // 
            // radioButtonMesh
            // 
            radioButtonMesh.AutoSize = true;
            radioButtonMesh.Location = new Point(90, 339);
            radioButtonMesh.Name = "radioButtonMesh";
            radioButtonMesh.Size = new Size(65, 24);
            radioButtonMesh.TabIndex = 9;
            radioButtonMesh.TabStop = true;
            radioButtonMesh.Text = "Mesh";
            radioButtonMesh.UseVisualStyleBackColor = true;
            radioButtonMesh.CheckedChanged += radioButtonMesh_CheckedChanged;
            // 
            // radioButtonSpere
            // 
            radioButtonSpere.AutoSize = true;
            radioButtonSpere.Location = new Point(8, 339);
            radioButtonSpere.Name = "radioButtonSpere";
            radioButtonSpere.Size = new Size(76, 24);
            radioButtonSpere.TabIndex = 9;
            radioButtonSpere.TabStop = true;
            radioButtonSpere.Text = "Sphere";
            radioButtonSpere.UseVisualStyleBackColor = true;
            radioButtonSpere.CheckedChanged += radioButtonSpere_CheckedChanged;
            // 
            // radioButton_box
            // 
            radioButton_box.AutoSize = true;
            radioButton_box.Location = new Point(9, 309);
            radioButton_box.Name = "radioButton_box";
            radioButton_box.Size = new Size(55, 24);
            radioButton_box.TabIndex = 9;
            radioButton_box.TabStop = true;
            radioButton_box.Text = "Box";
            radioButton_box.UseVisualStyleBackColor = true;
            radioButton_box.CheckedChanged += radioButton_box_CheckedChanged;
            // 
            // label_r
            // 
            label_r.AutoSize = true;
            label_r.Location = new Point(18, 159);
            label_r.Name = "label_r";
            label_r.Size = new Size(49, 20);
            label_r.TabIndex = 6;
            label_r.Text = "radius";
            // 
            // label_h
            // 
            label_h.AutoSize = true;
            label_h.Location = new Point(18, 122);
            label_h.Name = "label_h";
            label_h.Size = new Size(51, 20);
            label_h.TabIndex = 6;
            label_h.Text = "height";
            // 
            // label_w
            // 
            label_w.AutoSize = true;
            label_w.Location = new Point(18, 89);
            label_w.Name = "label_w";
            label_w.Size = new Size(46, 20);
            label_w.TabIndex = 7;
            label_w.Text = "width";
            // 
            // numericUpDown_r
            // 
            numericUpDown_r.DecimalPlaces = 2;
            numericUpDown_r.Location = new Point(90, 157);
            numericUpDown_r.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDown_r.Name = "numericUpDown_r";
            numericUpDown_r.Size = new Size(83, 27);
            numericUpDown_r.TabIndex = 3;
            // 
            // label_l
            // 
            label_l.AutoSize = true;
            label_l.Location = new Point(18, 56);
            label_l.Name = "label_l";
            label_l.Size = new Size(51, 20);
            label_l.TabIndex = 8;
            label_l.Text = "length";
            // 
            // numericUpDown_h
            // 
            numericUpDown_h.DecimalPlaces = 2;
            numericUpDown_h.Location = new Point(90, 120);
            numericUpDown_h.Maximum = new decimal(new int[] { 500, 0, 0, 0 });
            numericUpDown_h.Name = "numericUpDown_h";
            numericUpDown_h.Size = new Size(83, 27);
            numericUpDown_h.TabIndex = 3;
            // 
            // numericUpDown_w
            // 
            numericUpDown_w.DecimalPlaces = 2;
            numericUpDown_w.Location = new Point(90, 87);
            numericUpDown_w.Maximum = new decimal(new int[] { 500, 0, 0, 0 });
            numericUpDown_w.Name = "numericUpDown_w";
            numericUpDown_w.Size = new Size(83, 27);
            numericUpDown_w.TabIndex = 4;
            // 
            // numericUpDown_l
            // 
            numericUpDown_l.DecimalPlaces = 2;
            numericUpDown_l.Location = new Point(90, 54);
            numericUpDown_l.Maximum = new decimal(new int[] { 500, 0, 0, 0 });
            numericUpDown_l.Name = "numericUpDown_l";
            numericUpDown_l.Size = new Size(83, 27);
            numericUpDown_l.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(2, 201);
            label1.Name = "label1";
            label1.Size = new Size(25, 20);
            label1.TabIndex = 6;
            label1.Text = "ox";
            // 
            // numericUpDown_ox
            // 
            numericUpDown_ox.DecimalPlaces = 2;
            numericUpDown_ox.Location = new Point(32, 201);
            numericUpDown_ox.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDown_ox.Name = "numericUpDown_ox";
            numericUpDown_ox.Size = new Size(80, 27);
            numericUpDown_ox.TabIndex = 3;
            // 
            // numericUpDown_oy
            // 
            numericUpDown_oy.DecimalPlaces = 2;
            numericUpDown_oy.Location = new Point(32, 232);
            numericUpDown_oy.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDown_oy.Name = "numericUpDown_oy";
            numericUpDown_oy.Size = new Size(80, 27);
            numericUpDown_oy.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(2, 232);
            label2.Name = "label2";
            label2.Size = new Size(25, 20);
            label2.TabIndex = 6;
            label2.Text = "oy";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(2, 265);
            label3.Name = "label3";
            label3.Size = new Size(25, 20);
            label3.TabIndex = 6;
            label3.Text = "oz";
            // 
            // numericUpDown_oz
            // 
            numericUpDown_oz.DecimalPlaces = 2;
            numericUpDown_oz.Location = new Point(32, 263);
            numericUpDown_oz.Maximum = new decimal(new int[] { 300, 0, 0, 0 });
            numericUpDown_oz.Name = "numericUpDown_oz";
            numericUpDown_oz.Size = new Size(80, 27);
            numericUpDown_oz.TabIndex = 3;
            // 
            // GemotrySelector
            // 
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(734, 396);
            Controls.Add(groupBox);
            Controls.Add(labelBoundingBox);
            Controls.Add(groupBoxPos);
            Controls.Add(groupBoxRot);
            Controls.Add(buttonCancel);
            Controls.Add(buttonSetBox);
            Controls.Add(buttonOK);
            Controls.Add(radioButton1);
            Controls.Add(radioButton2);
            Name = "GemotrySelector";
            Text = "GemotrySelector";
            groupBoxPos.ResumeLayout(false);
            groupBoxPos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownX).EndInit();
            groupBoxRot.ResumeLayout(false);
            groupBoxRot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownRotZ).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownRotY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownRotX).EndInit();
            groupBox.ResumeLayout(false);
            groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_r).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_h).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_w).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_l).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_ox).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_oy).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown_oz).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelBoundingBox;
        private GroupBox groupBoxPos;
        private Label labelZ;
        private Label labelY;
        private Label labelX;
        private NumericUpDown numericUpDownZ;
        private NumericUpDown numericUpDownY;
        private NumericUpDown numericUpDownX;
        private GroupBox groupBoxRot;
        private Label labelRotZ;
        private Label labelRotY;
        private Label labelRotX;
        private NumericUpDown numericUpDownRotZ;
        private NumericUpDown numericUpDownRotY;
        private NumericUpDown numericUpDownRotX;
        private Button buttonCancel;
        private Button buttonOK;

        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button buttonSetBox;
        private GroupBox groupBox;
        private RadioButton radioButtonCylinder;
        private RadioButton radioButtonMesh;
        private RadioButton radioButtonSpere;
        private RadioButton radioButton_box;
        private Label label_r;
        private Label label_h;
        private Label label_w;
        private NumericUpDown numericUpDown_r;
        private Label label_l;
        private NumericUpDown numericUpDown_h;
        private NumericUpDown numericUpDown_w;
        private NumericUpDown numericUpDown_l;
        private Label label3;
        private Label label2;
        private Label label1;
        private NumericUpDown numericUpDown_oz;
        private NumericUpDown numericUpDown_oy;
        private NumericUpDown numericUpDown_ox;
    }
}