﻿

#pragma warning disable CA1416

//using System.Windows.Media;
using LCAMPConfigurator.ColorManagement;
using LCAMPConfigurator.Core;
using Newtonsoft.Json;
using SharpGLTF.Schema2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using static LCAMPConfigurator.ColorManagement.ColorSchemes;
using static System.Net.Mime.MediaTypeNames;
using static System.Resources.ResXFileRef;

namespace LCAMPConfigurator.UI
{
    public partial class CoolorSchemeControl : UserControl
    {

        public CoolorSchemeControl()
        {
            InitializeComponent();
        }


        bool tireSelected = false;
        ColorSchemes myScheme;

        private ColorSchemeFile cs_data { get; set; }
        // Event deklarieren
        public event Action<(string, string, string, RobComponent)> StatusChanged;


        public MaterialSelector materialPicker { get; set; }

        // Hilfsmethode mit optionalem Parameter
        public void RaiseStatusChanged(string lable, string text, string? mode = null, RobComponent? comp = null)
        {
            StatusChanged?.Invoke((lable, text, mode, comp));
        }


        private void CoolorSchemeControl_Load(object sender, EventArgs e)
        {
            // Design-Time Check hinzufügen
            if (this.DesignMode)
                return; // Im Designer nichts ausführen
            Console.WriteLine("ColorSchemes loades");
            cs_data = ColorSchemes.GetDefaultColorSchems();
            comboBoxColorscheme.DataSource = cs_data.SchemeList.Keys.ToList();

        }

        private void loadColorSchems()
        {
            string path = FileUtils.GetTemplatePath("Color");
            var dir = Directory.GetFiles(path);
            comboBoxExtColorSceems.Items.Clear();
            foreach (var file in dir)
            {
                string scemeName = Path.GetFileNameWithoutExtension(file);
                switch (ColorSchemes.CheckValidColorScheme(file))
                {
                    case -5:  //Exception
                    case -4: //Error
                    case -3:
                    case -2:
                    case -1:
                        break;
                    case 0: // Valid but no Colors
                    case 1:
                        comboBoxExtColorSceems.Items.Add(scemeName);
                        break;
                    case 2: // Valid an at least on dynamic Color
                        comboBoxExtColorSceems.Items.Add(scemeName + " (*)");
                        break;

                }
            }
        }

        private void buttonApply_Click(object sender, EventArgs e)
        {
            ApplyColorScheme();
        }

        public  void ApplyColorScheme()

        {
            string selected = comboBoxColorscheme.Text;

            string selectedExt = comboBoxExtColorSceems.Text.Replace("(*)","").Trim();

            Console.WriteLine($"Action: Apply Color Scheme  {selected}_{selectedExt}");

            var colors = new Dictionary<string, System.Drawing.Color>
            {
            { "Base",   panel_c1.BackColor },
            { "Main",   panel_c2.BackColor },
            { "Detail", panel_c3.BackColor },
            { "Accent", panel_c4.BackColor },
            { "Tire",   panel_c5.BackColor }};

            var newMaterials = new Dictionary<string, Materials>
            {
            { "Base",    panel_c1.Tag as Materials },
            { "Main",    panel_c2.Tag as Materials },
            { "Detail",  panel_c3.Tag as Materials},
            { "Accent",  panel_c4.Tag as Materials },
            { "Tire",    panel_c5.Tag as Materials }};

     
            var setScheme=SetExtColorSceem();
            if (setScheme != null)
            {
                RaiseStatusChanged("Update", $"Color Scheme Applyed!", null, null);
                return; 
            }

            myScheme = new ColorSchemes(selectedExt, colors, newMaterials); //todo hier sollte immer das gewählte Schema aus der Dropbox verwendet werden
           

            var parent = this.FindForm() as IRobotHost;
            var robi = parent.ActRobot as LCAMPRobot;
            if (robi != null)
            {
                try
                {
                    myScheme.ApplyColorScheme(robi);
                    RaiseStatusChanged("Status", $"Color Scheme Applyed!");
                    Export_GLB();
                    RaiseStatusChanged("Update", $"Color Scheme Applyed!",null, robi);


                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: could not applay color scheme  {ex}");
                    RaiseStatusChanged("Status", $"could not applay color scheme  {ex.Message}!", "Error");

                }
            }
            else
            {
                RaiseStatusChanged("Status", "no Robot Defined!", "Warning");
            }

        }

        Materials getMaterialCollor()
        {
            try
            {
                if (materialPicker == null)
                    materialPicker = new MaterialSelector();

                materialPicker.LoadJsonDataList(FileUtils.GetDataPath("Materials", "MateriallisteLCAMP.json"));

                if (materialPicker.ShowDialog() == DialogResult.OK)
                {
                    return materialPicker.SelectedMaterial;
                }
            }
                catch(Exception ex){
                Console.WriteLine($"Error: could not getMaterialCollor  {ex}");

            }
            return null;
        }
        #region PanelColorHandlig
        private void panel_c1_Click(object sender, EventArgs e)
        {
            if (checkBoxMaterials.Checked)
            {
                var mat = getMaterialCollor();
                if (mat != null)
                {
                    panel_c1.BackColor = mat.Color.Col;
                    panel_c1.Tag = mat; 
                    label_c1.Text = $"Base: {mat.Name}\n{ComponentHelper.ColorToHex(panel_c1.BackColor)}";
                }
            }
            else if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                panel_c1.BackColor = colorDialog.Color;
                label_c1.Text = $"Base\n{ComponentHelper.ColorToHex(panel_c1.BackColor)}";

            }
        }

        private void panel_c2_Click(object sender, EventArgs e)
        {
            if (checkBoxMaterials.Checked)
            {
                var mat = getMaterialCollor();
                if (mat != null)
                {
                    panel_c2.BackColor = mat.Color.Col;
                    panel_c2.Tag = mat;
                    label_c2.Text = $"Main: {mat.Name}\n{ComponentHelper.ColorToHex(panel_c2.BackColor)}";
                }
            }
            else if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                panel_c2.BackColor = colorDialog.Color;
                label_c2.Text = $"Main\n{ComponentHelper.ColorToHex(panel_c2.BackColor)}";

            }
        }

        private void panel_c3_Click(object sender, EventArgs e)
        {
            if (checkBoxMaterials.Checked)
            {
                var mat = getMaterialCollor();
                if (mat != null)
                {
                    panel_c3.BackColor = mat.Color.Col;
                    panel_c3.Tag = mat;
                    label_c3.Text = $"Detail: {mat.Name}\n{ComponentHelper.ColorToHex(panel_c3.BackColor)}";
                }
            }
            else if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                panel_c3.BackColor = colorDialog.Color;
                label_c3.Text = $"Detail\n{ComponentHelper.ColorToHex(panel_c3.BackColor)}";

            }
        }

        private void panel_c4_Click(object sender, EventArgs e)
        {
            if (checkBoxMaterials.Checked)
            {
                var mat = getMaterialCollor();
                if (mat != null)
                {
                    panel_c4.BackColor = mat.Color.Col;
                    panel_c4.Tag = mat;
                    label_c4.Text = $"Accent: {mat.Name}\n{ComponentHelper.ColorToHex(panel_c4.BackColor)}";
                }
            }
            else if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                panel_c4.BackColor = colorDialog.Color;
                label_c4.Text = $"Accent\n{ComponentHelper.ColorToHex(panel_c4.BackColor)}";

            }
        }


        private void panel_c5_Click(object sender, EventArgs e)
        {
            if (tireSelected)
            {
                if (checkBoxMaterials.Checked)
                {
                    var mat = getMaterialCollor();
                    if (mat != null)
                    {
                        panel_c5.BackColor = mat.Color.Col;
                        panel_c5.Tag = mat;
                        label_c5.Text = $"Tire: {mat.Name}\n{ComponentHelper.ColorToHex(panel_c5.BackColor)}";
                    }
                }

                else if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    panel_c5.BackColor = colorDialog.Color;
                    label_c5.Text = $"Tire\n{ComponentHelper.ColorToHex(panel_c5.BackColor)}";

                }
            }
            else
                Console.WriteLine($"Change only if colorset with Tire is selected");
        }

        #endregion

        public void SetColorSchemePanels(Dictionary<string, string>  scheme) { 
        string baseColor = scheme["Base"];
                string mainColor = scheme["Main"];
                string detailColor = scheme["Detail"];
                string accentColor = scheme["Accent"];


                // Beispiel: Panel einfärben
                panel_c1.BackColor = ColorTranslator.FromHtml(baseColor);
                label_c1.Text = $"Base\n{baseColor}";
                panel_c2.BackColor = ColorTranslator.FromHtml(mainColor);
                label_c2.Text = $"Main\n{mainColor}";
                panel_c3.BackColor = ColorTranslator.FromHtml(detailColor );
                label_c3.Text = $"Detail\n{detailColor}";
                panel_c4.BackColor = ColorTranslator.FromHtml(accentColor);
                label_c4.Text = $"Accent\n{accentColor}";

                if (scheme.ContainsKey("Tire"))
                {
                    string tireColor = scheme["Tire"];
                    panel_c5.BackColor = ColorTranslator.FromHtml(tireColor);
                    label_c5.Text = $"Tire\n{tireColor}";
                    if (tireColor != null)
                    {
                        tireSelected = true;
                        label_c5.Enabled = true;
                    }
                    else
                    {
                        tireSelected = false;
                        label_c5.Enabled = false;
                    }

            }
                else
                {
                    tireSelected = false;
                    label_c5.Enabled = false;
                }



            }
        

        private void buttonAdd_Click(object sender, EventArgs e)
        {

            var newColors = new Dictionary<string, string>
            {
            { "Base",   ComponentHelper.ColorToHex(panel_c1.BackColor) },
            { "Main",   ComponentHelper.ColorToHex(panel_c2.BackColor) },
            { "Detail", ComponentHelper.ColorToHex(panel_c3.BackColor) },
            { "Accent", ComponentHelper.ColorToHex(panel_c4.BackColor) },
            { "Tire",   ComponentHelper.ColorToHex(panel_c5.BackColor) }};

            // prüfen ob der Eintrag bereits in der Liste ist
            bool exists = comboBoxColorscheme.Items.Cast<object>()
                                          .Any(item => item.ToString().Equals(comboBoxColorscheme.Text, StringComparison.OrdinalIgnoreCase));

            if (!exists)
            {
                string newSchemeName = comboBoxColorscheme.Text;
                if (string.IsNullOrWhiteSpace(newSchemeName))
                    newSchemeName = "MyCustomScheme";

                // Vor dem Hinzufügen prüfen, ob der Key schon existiert
                if (!cs_data.SchemeList.ContainsKey(newSchemeName))
                {
                    cs_data.SchemeList.Add(newSchemeName, newColors);
                }
                else
                {
                    // überschreiben, wenn bereits vorhanden
                    cs_data.SchemeList[newSchemeName] = newColors;
                }

                comboBoxColorscheme.DataSource = cs_data.SchemeList.Keys.ToList();

                string output = JsonConvert.SerializeObject(cs_data, Formatting.Indented);
                //     File.WriteAllText(filePath, output);
            }
        }



        private void comboSchemes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = comboBoxColorscheme.SelectedItem.ToString();

            if (cs_data.SchemeList.TryGetValue(selected, out var scheme))
            {
                SetColorSchemePanels(scheme);
            }
        }

        private async void buttonExport_Click(object sender, EventArgs e)
        {
            Export_GLB();
        }

        public async void Export_GLB()

        {
            string outputGlb = FileUtils.GetTemplatePath("web","mobilerobot.glb");

            if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift)
            {
                try
                {
                    using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                    {
                        saveFileDialog.InitialDirectory = FileUtils.GetTemplatePath();
                        saveFileDialog.Filter = "GLB files (*.glb)|*.glb|All files (*.*)|*.*";
                        saveFileDialog.Title = "Select GLB-File for Output";
                        if (saveFileDialog.ShowDialog() == DialogResult.OK)
                        {
                            outputGlb = saveFileDialog.FileName;
                            // Hier kannst du mit der ausgewählten Datei weiterarbeiten
                            Console.WriteLine($"Datei ausgewählt: {outputGlb}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: could not Export the .glb File color scheme  {ex}");
                }

            }

        


              

            GLTF_RobotConverter converter = new GLTF_RobotConverter();
            var parent = this.FindForm() as IRobotHost;
            var robi = parent.ActRobot as LCAMPRobot;
            if (robi != null)
            {
                try
                {
                    await Task.Run(() => converter.CreateRobotModel(robi, outputGlb));
                    string outputGlb2 = FileUtils.GetOutputPath("mobilerobot.glb");
                    await using FileStream source = File.OpenRead(outputGlb);
                    await using FileStream dest = File.Create(outputGlb2);
                    await source.CopyToAsync(dest);


                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: could not Export the .glb File color scheme  {ex}");
                }
            }

        }


        /// <summary>
        /// sets the current values to the selected Colorscheeme
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void buttonUpdate_ClickAsync(object sender, EventArgs e)
        {
            // Set Currrent colors to selected List
            string selected = comboBoxColorscheme.Text;

            try
            {
                // prüfen ob der Eintrag bereits in der Liste ist
                bool exists = comboBoxColorscheme.Items.Cast<object>()
                                              .Any(item => item.ToString().Equals(comboBoxColorscheme.Text, StringComparison.OrdinalIgnoreCase));

            var newMaterials = new Dictionary<string, Materials>
            {
            { "Base",    panel_c1.Tag as Materials },
            { "Main",    panel_c2.Tag as Materials },
            { "Detail",  panel_c3.Tag as Materials},
            { "Accent",  panel_c4.Tag as Materials },
            { "Tire",    panel_c5.Tag as Materials }};

            if (cs_data.SchemeListMaterials == null)
                cs_data.SchemeListMaterials = new Dictionary<string, Dictionary<string, Materials>>();


                if (exists)
                {
                    if (cs_data.SchemeList.TryGetValue(selected, out var scheme))
                    {
                        string baseColor = scheme["Base"] = ComponentHelper.ColorToHex(panel_c1.BackColor);
                        string mainColor = scheme["Main"] = ComponentHelper.ColorToHex(panel_c2.BackColor);
                        string detailColor = scheme["Detail"] = ComponentHelper.ColorToHex(panel_c3.BackColor);
                        string accentColor = scheme["Accent"] = ComponentHelper.ColorToHex(panel_c4.BackColor);
                        string tireColor = scheme["Tire"] = ComponentHelper.ColorToHex(panel_c5.BackColor);

                    }
                    if (cs_data.SchemeListMaterials.TryGetValue(selected, out var schemeMaterial))
                    {
                        schemeMaterial["Base"] = panel_c1.Tag as Materials;
                        schemeMaterial["Main"] = panel_c2.Tag as Materials;
                        schemeMaterial["Detail"] = panel_c3.Tag as Materials;
                        schemeMaterial["Accent"] = panel_c4.Tag as Materials;
                        schemeMaterial["Tire"] = panel_c5.Tag as Materials;
                    }
                    else
                    {
                        if (cs_data.SchemeListMaterials.ContainsKey(selected))
                            cs_data.SchemeListMaterials[selected]=newMaterials;
                        else
                            cs_data.SchemeListMaterials.Add(selected, newMaterials);

                    }
                    comboBoxColorscheme.SelectedItem = selected;
                    string text = comboBoxExtColorSceems.Text;
                    await Task.Run(() => SetExtColorSceem(text));
                    RaiseStatusChanged("Update", $"Color Scheme Applyed!", null, null);

                }
                else
                {
                    var newColors = new Dictionary<string, string>
                    {
                    { "Base",   ComponentHelper.ColorToHex(panel_c1.BackColor) },
                    { "Main",   ComponentHelper.ColorToHex(panel_c2.BackColor) },
                    { "Detail", ComponentHelper.ColorToHex(panel_c3.BackColor) },
                    { "Accent", ComponentHelper.ColorToHex(panel_c4.BackColor) },
                    { "Tire",   ComponentHelper.ColorToHex(panel_c5.BackColor) }};



                    if (string.IsNullOrWhiteSpace(selected))
                        selected = "MyCustomScheme";



                    // Vor dem Hinzufügen prüfen, ob der Key schon existiert
                    if (!cs_data.SchemeList.ContainsKey(selected))
                    {
                        cs_data.SchemeList.Add(selected, newColors);
                        cs_data.SchemeListMaterials.Add(selected, newMaterials);
                    }

                    else
                    {
                        // überschreiben, wenn bereits vorhanden
                        cs_data.SchemeList[selected] = newColors;
                        cs_data.SchemeListMaterials[selected] = newMaterials;

                    }

                    comboBoxColorscheme.DataSource = cs_data.SchemeList.Keys.ToList();
                    comboBoxColorscheme.SelectedItem = selected;
                    string text = comboBoxExtColorSceems.Text;
                    await Task.Run(() => SetExtColorSceem(text));
                    RaiseStatusChanged("Update", $"Color Scheme Applyed!", null, null);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: could not applay color scheme  {ex}");
            }

        }


        private void comboBoxExtColorSceems_DropDown(object sender, EventArgs e)
        {
            //  if(comboBoxExtColorSceems.Items.Count==0)
            loadColorSchems();
        }

        private async void comboBoxExtColorSceems_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                await Task.Run(() => SetExtColorSceem()); 

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: could not Export the .glb File color scheme  {ex}");
            }
 
        }

        private ColorSchemes SetExtColorSceem()
        {
            string schemeName;
            if (comboBoxExtColorSceems.SelectedItem == null)
            {
                schemeName = comboBoxExtColorSceems.Text;
            }
            else
            {
                // Name aus der ComboBox holen
                schemeName = comboBoxExtColorSceems.SelectedItem.ToString();
            }
            return SetExtColorSceem(schemeName);
        }

        private ColorSchemes SetExtColorSceem(string schemeName)
        {
            var myColors = new Dictionary<string, string>
            {
            { "Base",   ComponentHelper.ColorToHex(panel_c1.BackColor) },
            { "Main",   ComponentHelper.ColorToHex(panel_c2.BackColor) },
            { "Detail", ComponentHelper.ColorToHex(panel_c3.BackColor) },
            { "Accent", ComponentHelper.ColorToHex(panel_c4.BackColor) },
            { "Tire",   ComponentHelper.ColorToHex(panel_c5.BackColor) }
            };

            // Dateiname erstellen (z. B. "red.json")
            string fileName = $"{schemeName.Replace("(*)", "").Trim()}.json";
            var fullPath = FileUtils.GetTemplatePath("Color", fileName);
            if (File.Exists(fullPath))
            {
                myScheme = ColorSchemes.LoadDynamicScheme(fullPath, myColors);
                if(schemeName.EndsWith("(*)"))
                    myScheme.isDynamic = true;
                else
                    myScheme.isDynamic = false;


                var parent = this.FindForm() as IRobotHost;
                var robi = parent.ActRobot as LCAMPRobot;
                if (robi != null)
                {
                    try
                    {
                        myScheme.ApplyColorScheme(robi);
                        RaiseStatusChanged("Status", $"Color Scheme Applyed!");
                        Export_GLB();
                 //       RaiseStatusChanged("Update", $"Color Scheme Applyed!", null, robi);
                        return myScheme;


                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: could not applay color scheme  {ex}");
                        RaiseStatusChanged("Status", $"could not applay color scheme  {ex.Message}!", "Error");

                    }
                }
                else
                {
                    Console.WriteLine($"Warning: no Robot Defined!");

                    RaiseStatusChanged("Status", "no Robot Defined!", "Warning");
                }
            }
            return null;
        }


        private void panel_c5_DoubleClick(object sender, EventArgs e)
        {
            tireSelected = true;
            label_c5.Enabled = true;

        }

        private void comboBoxColorscheme_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && comboBoxExtColorSceems.SelectedItem != null)
            {
                comboBoxExtColorSceems.Items.Remove((string)comboBoxExtColorSceems.SelectedItem);
            }
        }

        private void buttonSave_ClickAsync(object sender, EventArgs e)
        {
            try
            {
                buttonUpdate_ClickAsync(sender, e);  // Always Update first

                string output = JsonConvert.SerializeObject(cs_data, Formatting.Indented);
                File.WriteAllText(ColorSchemes.FilePath, output);
                if (myScheme != null && myScheme.isDynamic)  // Save only is it is dynmaic
                {


                    myScheme.Name = comboBoxColorscheme.Text + "_" + myScheme.Name;
                    string mySchemeOutput = JsonConvert.SerializeObject(myScheme, Formatting.Indented);
                    string fName = FileUtils.GetTemplatePath("Color", myScheme.Name + ".json");
                    File.WriteAllText(fName, mySchemeOutput);
                }
            }
            catch (Exception ex) { 
                Console.WriteLine($"Error: could not Save as .json File color scheme {myScheme?.Name} {ex}");
            }

        }
    }
}
