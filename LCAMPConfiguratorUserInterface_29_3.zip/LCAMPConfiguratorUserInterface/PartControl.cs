﻿

#pragma warning disable CA1416

using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using LCAMPConfigurator.Core;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using LCAMPConfiguratorUserInterface;

namespace LCAMPConfigurator.UI
{
    public partial class PartControl : UserControl
    {

        // 1️⃣ Event definieren
        public event Action<(string, string, string, RobComponent)> PartUpdated;


        public RobComponent selElement { get; set; }
        protected PartDescription? selectedPart { get; set; }
        private LinkDefinition? selectedGeometry { get; set; }

        public Materials MaterialList { get; set; }

        public PartControl()
        {
            InitializeComponent();
        }

        public void InitCompElements(RobComponent part)
        {
            textBoxName.Text = part.Name;
            textBox2.Text = "-";
            textBox3.Text = "-";




            textBox5.Text = part.Description;
            textBoxData3D.Text = "-";
            textBoxGeom.Text = "-";
            textBoxReference.Text = "-";

            if (part.Components.Count > 0)
                labelType.Text = $"Type: Assembly {part.Type} with {part.Components.Count} elements";
            else
                labelType.Text = $"Type: {part.Type}";
            labelParent.Text = part.Parent;
            labelNumber.Text = " ";
            labelId.Text = "id: 0x" + part.Id.ToString("x");

            foreach (RobComponent elem in part.Components)
            {
                comboBox4.Items.Add(elem);
            }
        }



        public void InitElements(RobComponent comp)
        {
            try
            {
                this.Visible = true;
                //this.Dock = DockStyle.Fill; // Layout-Refresh
                this.Parent.PerformLayout();
                this.Parent.Invalidate();  // optional für Neuzeichnen

                selElement = comp;
                selectedPart = null;
                selectedGeometry = null;

                textBoxName.Text = comp.Name;
                labelidCode.Enabled = false;
                textBox2.Text = "";
                textBox3.Text = "...";

                labelMaterial.Enabled = false;
                buttonMaterialPicker.Enabled = false;
                buttonMaterialPicker.UseVisualStyleBackColor = true;



                textBox4.Text = "0x" + comp.Id.ToString("x");
                textBox5.Text = comp.Description;
                textBoxData3D.Text = "-";
                label3dData.Enabled = false;
                buttonData3DSelector.Enabled = false;
                textBoxGeom.Text = "...";
                textBoxReference.Text = comp.Reference;
                labelGeometry.Enabled = false;
                buttonGeometrySelection.Enabled = false;

                labelParent.Text = comp.Parent;
                labelId.Text = "id: 0x" + comp.Id.ToString("x");
                comboBox4.Items.Clear();
                foreach (RobComponent elem in comp.Components)
                {
                    comboBox4.Items.Add(elem);
                }


                labelClassType.Text = $"Class: {comp.ComponentType} : {comp.GetType().FullName}";
                if (comp.Components.Count > 0)
                    labelType.Text = $"Type: Assembly {comp.Type} with {comp.Components.Count} elements";
                else
                    labelType.Text = $"Type: {comp.Type}";


            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: InitElements not sucessfull in {comp.Name}: " + ex);
            }
        }
        public void InitElements(Device dev)
        {
            try
            {
                InitElements((RobComponent)dev);
                selectedGeometry = dev.Geometry;
                labelGeometry.Enabled = true;
                buttonGeometrySelection.Enabled = true;
                if (dev.Geometry != null)
                {
                    textBoxGeom.Text = dev.Geometry.ToString();
                }
                else
                {
                    textBoxGeom.Text = "...";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: InitElements not sucessfull in {selElement.Name}: " + ex);
            }
        }

        public void InitElements(SubSystem subdev)
        {
            try
            {
                InitElements((RobComponent)subdev);
                selectedGeometry = subdev.Geometry;
                labelGeometry.Enabled = true;
                buttonGeometrySelection.Enabled = true;
                if (subdev.Geometry != null)
                {
                    textBoxGeom.Text = subdev.Geometry.ToString();
                }
                else
                {
                    textBoxGeom.Text = "...";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: InitElements not sucessfull in {selElement.Name}: " + ex);
            }
        }


        public void InitElements(PartDescription part)
        {
            try
            {
                InitElements((RobComponent)part);

                PartDescription selPart = part;

                labelidCode.Enabled = true;
                labelMaterial.Enabled = true;
                buttonMaterialPicker.Enabled = true;
                if (part.Material != null)
                {
                    buttonMaterialPicker.UseVisualStyleBackColor = false;
                    buttonMaterialPicker.BackColor = part.Material.Color.Col;
                }

                labelGeometry.Enabled = true;
                buttonGeometrySelection.Enabled = true;
                label3dData.Enabled = true;
                buttonData3DSelector.Enabled = true;


                selectedPart = selPart;
                selectedGeometry = selPart.Geometry;

                if (selPart.IdCode == null)
                    selPart.IdCode = new PartNumber(selPart).idCode;

                textBox2.Text = selPart.IdCode;

                if (selPart.Material != null)
                {

                    //   comboBox4.Text = Part.Material.Name;
                    textBox3.Text = selPart.Material.ToString();
                }
                else
                {
                    textBox3.Text = "...";
                }


                if (selPart.Data3D != null)
                {
                    textBoxData3D.Text = selPart.Data3D;
                }
                else
                {
                    textBoxData3D.Text = "...";
                }


                if (selPart.Geometry != null)
                {
                    textBoxGeom.Text = selPart.Geometry.ToString();
                }
                else
                {
                    textBoxGeom.Text = "...";
                }


                labelNumber.Text = "n: " + selPart.Number;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: InitElements not sucessfull in {selElement.Name}: " + ex);
            }
        }




        protected Materials RedefineMaterial(Materials material, string str)
        {
            // Setze neuen Mane
            Match matchName = Regex.Match(str, "'([^']*)'");
            var matchColor = Regex.Match(str, @"ARGB\s*\(\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\s*\)");

            if (material == null && (matchName != null || matchColor != null))
            {
                material = new Materials();
            }

            if (matchName != null)
                material.Name = matchName.Groups[1].Value;

            // Regex zum Extrahieren der RGBA-Werte

            if (matchColor.Success)
            {
                int a = int.Parse(matchColor.Groups[1].Value);
                int r = int.Parse(matchColor.Groups[2].Value);
                int g = int.Parse(matchColor.Groups[3].Value);
                int b = int.Parse(matchColor.Groups[4].Value);

                Console.WriteLine($"Gefundene Werte: R={r}, G={g}, B={b}, A={a}");
                material.Color.SetColor(a, r, g, b);
            }
            else
            {
                Console.WriteLine("Error: Keine RGBA-Werte gefunden.");
            }

            System.Drawing.Color? fColor = MaterialSelector.FindKnownColorFromArgb(material.Color.Col);
            if (fColor.HasValue)
            {
                material.Color.Col = fColor.Value; // Zuweisung
            }
            return material;
        }


        void UpdateElements()
        {
            //  if(Part.Number>1)
            //      Part.Name = $"{textBoxName.Text} [{Part.Number}]"; // Wenn höhere Anzahl dann im Baum Ausgeben
            //  else
            selElement.Name = textBoxName.Text;
            selElement.Description = textBox5.Text;
            selElement.Reference = textBoxReference.Text;
            selElement.Id = (int)ComponentHelper.readValue(textBox4.Text);


            Device? selDevice = (selElement as Device);
            if (selDevice != null)
            {
                selDevice.Geometry = ComponentHelper.RedefineGeometry(selDevice.Geometry, textBoxGeom.Text);

            }

            PartDescription selPart = (selElement as PartDescription);
            if (selPart != null)
            {
                if (selPart.Material != null)
                {
                    selPart.Material.Name = comboBox4.Text;
                    RedefineMaterial(selPart.Material, textBox3.Text);
                    if (selPart.Material.Reference != null)
                    {
                        selPart.Material.Reference = PartNumber.MaterialTo5LetterCode(selPart.Material);
                        selPart.Material.Reference = PartNumber.AddSubValue(selPart.Material.Reference, PartNumber.ColorTo4LetterCode(selPart.Material.Color.Col));
                    }
                }
                selPart.Data3D = Path.GetFileName(textBoxData3D.Text);
                if (textBoxData3D.Text.Length > 1)  // Specpath nur setzen wenn definiert
                    selPart.SpecPath = Path.GetDirectoryName(textBoxData3D.Text);
                else
                    selPart.SpecPath = null;
                //selElement.SetTreeNodeText(textBoxName.Text);
                (selElement.TreeNode as System.Windows.Forms.TreeNode).Text = textBoxName.Text;

                selPart.Geometry = ComponentHelper.RedefineGeometry(selPart.Geometry, textBoxGeom.Text);

                

                if (selPart.Material != null && textBoxReference.Text.Length > 0)
                    //    textBoxReference.Text = PartNumber.AddHashValue(textBoxReference.Text, selPart.Material.Name);

                    if (!textBoxReference.Text.EndsWith(selPart.Material.Reference))
                        textBoxReference.Text = PartNumber.AddSubValue(textBoxReference.Text, selPart.Material.Reference);

                selPart.Reference = textBoxReference.Text;
                selPart.IdCode = new PartNumber(selElement).idCode;

                textBox2.Text = selPart.IdCode.ToString();
            }

            PartUpdated?.Invoke(("Update", selPart.Name, "", selPart));
        }

        private void fillMaterialList()
        {

            comboBox4.Items.Clear();
            if (MaterialList != null)
                foreach (Materials mat in MaterialList.Components)
                    comboBox4.Items.Add(mat);
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateElements();


                //       this.Visible = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: UpdateElements {ex}");

            }
        }

        private void comboBox4_DropDown(object sender, EventArgs e)
        {
            //       fillMaterialList();
        }

        protected virtual void buttonMaterialPicker_Click(object sender, EventArgs e)
        {
            Console.WriteLine($"MaterialPicker_Click");
            MaterialSelector MatSel = new MaterialSelector()
            {
                SelectedMaterial = RedefineMaterial(selectedPart.Material, textBox3.Text)
            };
            // Mit Regex den Text zwischen einfachen Anführungszeichen extrahieren
            MatSel.LoadJsonDataList(FileUtils.GetDataPath("Materials", "MateriallisteLCAMP.json"));

            //      Match match = Regex.Match(textBox3.Text, "'([^']*)'");
            //      MatSel.SelectdMaterial(match.Groups[1].Value);
            //      MatSel.SelectdMaterial(MatSel.SelectedMaterial.Name);

            if (MatSel.ShowDialog() == DialogResult.OK)
            {
                if (MatSel.SelectedMaterial != null)
                    textBox3.Text = MatSel.SelectedMaterial.ToString();
                selectedPart.Material = MatSel.SelectedMaterial;
            }

        }

        protected virtual void buttonGeometrySelection_Click(object sender, EventArgs e)
        {
            Console.WriteLine($"GeometrySelection_Click");
            try
            {
                GemotrySelector GeoSel = new GemotrySelector()
                {
                    aLink = selectedGeometry
                };


                GeoSel.SetValues(ComponentHelper.RedefineGeometry(selectedGeometry, textBoxGeom.Text));
                if (GeoSel.ShowDialog() == DialogResult.OK)
                {
                    selectedGeometry = GeoSel.aLink;
                    textBoxGeom.Text = GeoSel.aLink.ToString();
                }
            }
            catch (Exception ex) { Console.WriteLine($"Error: GeometrySelection {ex}"); }
        }


        /// <summary>
        /// Öffnet einen Dialog, um einen Basisordner und eine Datei auszuwählen.
        /// </summary>
        /// <param name="initialDirectory">Optionaler Startordner</param>
        /// <param name="filter">Dateifilter, z.B. "Textdateien (*.txt)|*.txt|Alle Dateien (*.*)|*.*"</param>
        /// <returns>Pfad zur ausgewählten Datei oder null, wenn abgebrochen</returns>
        private void buttonData3DSelector_Click(object sender, EventArgs e)
        {
            string initialDirectory = FileUtils.GlobalConfig.DataPath;
            // initialDirectory = null;
            using (var dialog = new System.Windows.Forms.OpenFileDialog())
            {
                dialog.Title = "Choose File";
                dialog.Filter = "STL files (*.stl)|*.stl|All files (*.*)|*.*";
                dialog.FilterIndex = 1;

                dialog.FileName = textBoxData3D.Text;

                if (!string.IsNullOrEmpty(initialDirectory) && Directory.Exists(initialDirectory) && !string.IsNullOrWhiteSpace(dialog.FileName))
                {
                    string? fileName = Path.GetFileName(dialog.FileName);
                    string? directoryPath = Path.GetDirectoryName(dialog.FileName);
                    dialog.FileName = fileName;

                    dialog.InitialDirectory = Path.Combine(initialDirectory, directoryPath);
                }
                else
                {
                    if (Directory.Exists(initialDirectory))
                        dialog.InitialDirectory = initialDirectory;
                    else
                        dialog.InitialDirectory = FileUtils.GetDataPath();
                }
                dialog.FileName = textBoxData3D.Text;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    // Schritt 1: Pfad ohne Dateiname ermitteln
                    string? directoryPath = Path.GetDirectoryName(dialog.FileName);
                    string? fileName = Path.GetFileName(dialog.FileName);


                    // Schritt 2: Relative Pfadangabe erzeugen
                    string? relativePath = Path.GetRelativePath(dialog.InitialDirectory, directoryPath);
                    selectedPart.SpecPath = relativePath;
                    selectedPart.Data3D = fileName;
                    textBoxData3D.Text = Path.Combine(relativePath, fileName);
                }
                // return null;
            }
        }

        private void labelNumber_DoubleClick(object sender, EventArgs e)
        {
            Console.WriteLine($"Number");
            var form = new NumberPatternForm();
            form.FormatPattern = selectedPart.Number;
            if(form.ShowDialog() == DialogResult.OK)
            {
                selectedPart.Number = form.FormatPattern;
                labelNumber.Text = "n: " + selectedPart.Number;

            }
        }
    }
}
