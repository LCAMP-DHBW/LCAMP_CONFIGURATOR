﻿namespace LCAMPConfigurator.UI
{
    partial class ConfigurationTreeControl
    {
        /// <summary> 
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Komponenten-Designer generierter Code

        /// <summary> 
        /// Erforderliche Methode für die Designerunterstützung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            treeViewSystem = new TreeView();
            openFileDialogLoad = new OpenFileDialog();
            buttonLoad = new Button();
            buttonSave = new Button();
            saveFileDialogSaveAs = new SaveFileDialog();
            buttonClear = new Button();
            SuspendLayout();
            // 
            // treeViewSystem
            // 
            treeViewSystem.AllowDrop = true;
            treeViewSystem.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            treeViewSystem.BackColor = Color.FromArgb(250, 250, 240);
            treeViewSystem.HideSelection = false;
            treeViewSystem.Location = new Point(13, 74);
            treeViewSystem.Margin = new Padding(3, 4, 3, 4);
            treeViewSystem.Name = "treeViewSystem";
            treeViewSystem.Size = new Size(265, 479);
            treeViewSystem.TabIndex = 8;
        //    treeViewSystem.DragDrop += treeViewSystem_DragDrop;
        //    treeViewSystem.DragOver += treeViewSystem_DragOver;
            // 
            // openFileDialogLoad
            // 
            openFileDialogLoad.DefaultExt = "json";
            openFileDialogLoad.FileName = "RobiControl.json";
            openFileDialogLoad.Filter = "LCAMPConf (*.json)|*.json|Alle Dateien (*.*)|*.*";
            openFileDialogLoad.Title = "Load LCAMP Robot config";
            openFileDialogLoad.FileOk += OpenFileDialogLoad_FileOk;
            // 
            // buttonLoad
            // 
            buttonLoad.Location = new Point(13, 13);
            buttonLoad.Margin = new Padding(3, 4, 3, 4);
            buttonLoad.Name = "buttonLoad";
            buttonLoad.Size = new Size(63, 29);
            buttonLoad.TabIndex = 9;
            buttonLoad.Text = "Load";
            buttonLoad.UseVisualStyleBackColor = true;
            buttonLoad.Click += buttonLoad_Click;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(80, 13);
            buttonSave.Margin = new Padding(3, 4, 3, 4);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(61, 29);
            buttonSave.TabIndex = 9;
            buttonSave.Text = "Save";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // saveFileDialogSaveAs
            // 
            saveFileDialogSaveAs.DefaultExt = "json";
            saveFileDialogSaveAs.Filter = "LCAMPConf (*.json)|*.json|Alle Dateien (*.*)|*.*";
            saveFileDialogSaveAs.Title = "Save LCAMP Robot config";
            saveFileDialogSaveAs.FileOk += SaveFileDialogSaveAs_FileOk;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(151, 13);
            buttonClear.Margin = new Padding(3, 4, 3, 4);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(62, 29);
            buttonClear.TabIndex = 9;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // ConfigurationTreeControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            AutoSize = true;
            Controls.Add(buttonClear);
            Controls.Add(buttonSave);
            Controls.Add(buttonLoad);
            Controls.Add(treeViewSystem);
            Margin = new Padding(3, 4, 3, 4);
            Name = "ConfigurationTreeControl";
            Size = new Size(297, 579);
            ResumeLayout(false);
        }

        #endregion

        public System.Windows.Forms.TreeView myTreeViewSystem { get => treeViewSystem;  }
        private System.Windows.Forms.TreeView treeViewSystem;
        private System.Windows.Forms.OpenFileDialog openFileDialogLoad;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.SaveFileDialog saveFileDialogSaveAs;
        private System.Windows.Forms.Button buttonClear;
    }
}
