﻿namespace LCAMPConfiguratorUserInterface
{
    partial class NumberPatternForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonOK = new Button();
            textBoxPattern = new TextBox();
            SuspendLayout();
            // 
            // buttonOK
            // 
            buttonOK.DialogResult = DialogResult.OK;
            buttonOK.Location = new Point(447, 139);
            buttonOK.Name = "buttonOK";
            buttonOK.Size = new Size(86, 36);
            buttonOK.TabIndex = 0;
            buttonOK.Text = "Ok";
            buttonOK.UseVisualStyleBackColor = true;
            buttonOK.Click += buttonOK_Click;
            // 
            // textBoxPattern
            // 
            textBoxPattern.Location = new Point(28, 41);
            textBoxPattern.Name = "textBoxPattern";
            textBoxPattern.Size = new Size(505, 27);
            textBoxPattern.TabIndex = 1;
            // 
            // NumberPatternForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(561, 199);
            Controls.Add(textBoxPattern);
            Controls.Add(buttonOK);
            Name = "NumberPatternForm";
            Text = "NumberPatternForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonOK;
        private TextBox textBoxPattern;
    }
}