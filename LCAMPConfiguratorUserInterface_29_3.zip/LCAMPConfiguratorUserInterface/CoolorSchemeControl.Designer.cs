﻿namespace LCAMPConfigurator.UI
{
    partial class CoolorSchemeControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
               
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel_c1 = new Panel();
            panel_c2 = new Panel();
            panel_c3 = new Panel();
            panel_c4 = new Panel();
            comboBoxColorscheme = new ComboBox();
            buttonApply = new Button();
            buttonSave = new Button();
            label_c1 = new Label();
            label_c2 = new Label();
            label_c3 = new Label();
            label_c4 = new Label();
            colorDialog = new ColorDialog();
            buttonExport = new Button();
            comboBoxExtColorSceems = new ComboBox();
            buttonAdd = new Button();
            textBoxName = new TextBox();
            panel_c5 = new Panel();
            label_c5 = new Label();
            checkBoxMaterials = new CheckBox();
            SuspendLayout();
            // 
            // panel_c1
            // 
            panel_c1.BackColor = SystemColors.ActiveCaption;
            panel_c1.BorderStyle = BorderStyle.FixedSingle;
            panel_c1.Location = new Point(31, 25);
            panel_c1.Name = "panel_c1";
            panel_c1.Size = new Size(52, 51);
            panel_c1.TabIndex = 0;
            panel_c1.Click += panel_c1_Click;
            // 
            // panel_c2
            // 
            panel_c2.BackColor = SystemColors.ActiveCaption;
            panel_c2.BorderStyle = BorderStyle.FixedSingle;
            panel_c2.Location = new Point(116, 25);
            panel_c2.Name = "panel_c2";
            panel_c2.Size = new Size(52, 51);
            panel_c2.TabIndex = 0;
            panel_c2.Click += panel_c2_Click;
            // 
            // panel_c3
            // 
            panel_c3.BackColor = SystemColors.ActiveCaption;
            panel_c3.BorderStyle = BorderStyle.FixedSingle;
            panel_c3.Location = new Point(206, 25);
            panel_c3.Name = "panel_c3";
            panel_c3.Size = new Size(52, 51);
            panel_c3.TabIndex = 0;
            panel_c3.Click += panel_c3_Click;
            // 
            // panel_c4
            // 
            panel_c4.BackColor = SystemColors.ActiveCaption;
            panel_c4.BorderStyle = BorderStyle.FixedSingle;
            panel_c4.Location = new Point(294, 25);
            panel_c4.Name = "panel_c4";
            panel_c4.Size = new Size(52, 51);
            panel_c4.TabIndex = 0;
            panel_c4.Click += panel_c4_Click;
            // 
            // comboBoxColorscheme
            // 
            comboBoxColorscheme.FormattingEnabled = true;
            comboBoxColorscheme.Location = new Point(73, 179);
            comboBoxColorscheme.Name = "comboBoxColorscheme";
            comboBoxColorscheme.Size = new Size(293, 28);
            comboBoxColorscheme.TabIndex = 1;
            comboBoxColorscheme.SelectedIndexChanged += comboSchemes_SelectedIndexChanged;
            comboBoxColorscheme.KeyDown += comboBoxColorscheme_KeyDown;
            // 
            // buttonApply
            // 
            buttonApply.Location = new Point(452, 135);
            buttonApply.Name = "buttonApply";
            buttonApply.Size = new Size(161, 29);
            buttonApply.TabIndex = 2;
            buttonApply.Text = "Apply Scheme";
            buttonApply.UseVisualStyleBackColor = true;
            buttonApply.Click += buttonApply_Click;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(294, 239);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(68, 29);
            buttonSave.TabIndex = 2;
            buttonSave.Text = "Save";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_ClickAsync;
            // 
            // label_c1
            // 
            label_c1.AutoSize = true;
            label_c1.Location = new Point(31, 90);
            label_c1.Name = "label_c1";
            label_c1.Size = new Size(40, 20);
            label_c1.TabIndex = 3;
            label_c1.Text = "Base";
            // 
            // label_c2
            // 
            label_c2.AutoSize = true;
            label_c2.Location = new Point(116, 90);
            label_c2.Name = "label_c2";
            label_c2.Size = new Size(42, 20);
            label_c2.TabIndex = 3;
            label_c2.Text = "Main";
            // 
            // label_c3
            // 
            label_c3.AutoSize = true;
            label_c3.Location = new Point(206, 90);
            label_c3.Name = "label_c3";
            label_c3.Size = new Size(49, 20);
            label_c3.TabIndex = 3;
            label_c3.Text = "Detail";
            // 
            // label_c4
            // 
            label_c4.AutoSize = true;
            label_c4.Location = new Point(292, 90);
            label_c4.Name = "label_c4";
            label_c4.Size = new Size(54, 20);
            label_c4.TabIndex = 3;
            label_c4.Text = "Accent";
            // 
            // colorDialog
            // 
            colorDialog.Color = Color.Transparent;
            // 
            // buttonExport
            // 
            buttonExport.Location = new Point(452, 179);
            buttonExport.Name = "buttonExport";
            buttonExport.Size = new Size(94, 29);
            buttonExport.TabIndex = 2;
            buttonExport.Text = "generat glb";
            buttonExport.UseVisualStyleBackColor = true;
            buttonExport.Click += buttonExport_Click;
            // 
            // comboBoxExtColorSceems
            // 
            comboBoxExtColorSceems.FormattingEnabled = true;
            comboBoxExtColorSceems.Location = new Point(452, 25);
            comboBoxExtColorSceems.Name = "comboBoxExtColorSceems";
            comboBoxExtColorSceems.Size = new Size(174, 28);
            comboBoxExtColorSceems.TabIndex = 1;
            comboBoxExtColorSceems.Text = "dynamic (*)";
            comboBoxExtColorSceems.DropDown += comboBoxExtColorSceems_DropDown;
            comboBoxExtColorSceems.SelectedIndexChanged += comboBoxExtColorSceems_SelectedIndexChanged;
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(73, 239);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(77, 29);
            buttonAdd.TabIndex = 2;
            buttonAdd.Text = "Update";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonUpdate_ClickAsync;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(165, 239);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(115, 27);
            textBoxName.TabIndex = 4;
            // 
            // panel_c5
            // 
            panel_c5.BackColor = SystemColors.ActiveCaptionText;
            panel_c5.BorderStyle = BorderStyle.FixedSingle;
            panel_c5.Location = new Point(378, 25);
            panel_c5.Name = "panel_c5";
            panel_c5.Size = new Size(27, 51);
            panel_c5.TabIndex = 0;
            panel_c5.Click += panel_c5_Click;
            panel_c5.DoubleClick += panel_c5_DoubleClick;
            // 
            // label_c5
            // 
            label_c5.AutoSize = true;
            label_c5.Enabled = false;
            label_c5.Location = new Point(376, 90);
            label_c5.Name = "label_c5";
            label_c5.Size = new Size(34, 20);
            label_c5.TabIndex = 3;
            label_c5.Text = "Tire";
            // 
            // checkBoxMaterials
            // 
            checkBoxMaterials.AutoSize = true;
            checkBoxMaterials.Location = new Point(73, 140);
            checkBoxMaterials.Name = "checkBoxMaterials";
            checkBoxMaterials.Size = new Size(118, 24);
            checkBoxMaterials.TabIndex = 6;
            checkBoxMaterials.Text = "use Materials";
            checkBoxMaterials.UseVisualStyleBackColor = true;
            // 
            // CoolorSchemeControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            Controls.Add(checkBoxMaterials);
            Controls.Add(textBoxName);
            Controls.Add(label_c5);
            Controls.Add(label_c4);
            Controls.Add(label_c3);
            Controls.Add(label_c2);
            Controls.Add(label_c1);
            Controls.Add(buttonSave);
            Controls.Add(buttonAdd);
            Controls.Add(buttonExport);
            Controls.Add(buttonApply);
            Controls.Add(comboBoxExtColorSceems);
            Controls.Add(comboBoxColorscheme);
            Controls.Add(panel_c5);
            Controls.Add(panel_c4);
            Controls.Add(panel_c3);
            Controls.Add(panel_c2);
            Controls.Add(panel_c1);
            Name = "CoolorSchemeControl";
            Size = new Size(692, 346);
            Load += CoolorSchemeControl_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel_c1;
        private System.Windows.Forms.Panel panel_c2;
        private System.Windows.Forms.Panel panel_c3;
        private System.Windows.Forms.Panel panel_c4;
        private System.Windows.Forms.ComboBox comboBoxColorscheme;
        private System.Windows.Forms.Button buttonApply;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label label_c1;
        private System.Windows.Forms.Label label_c2;
        private System.Windows.Forms.Label label_c3;
        private System.Windows.Forms.Label label_c4;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button buttonExport;
        private System.Windows.Forms.ComboBox comboBoxExtColorSceems;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.TextBox textBoxName;
        private Panel panel_c5;
        private Label label_c5;
        private CheckBox checkBoxMaterials;
    }
}