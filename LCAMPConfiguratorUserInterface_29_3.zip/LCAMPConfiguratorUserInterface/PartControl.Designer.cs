﻿using System.Windows.Forms;

namespace LCAMPConfigurator.UI
{
    partial class PartControl
    {
        /// <summary> 
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Komponenten-Designer generierter Code

        /// <summary> 
        /// Erforderliche Methode für die Designerunterstützung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            buttonUpdate = new Button();
            label1 = new Label();
            textBoxName = new TextBox();
            labelidCode = new Label();
            labelMaterial = new Label();
            label10 = new Label();
            label5 = new Label();
            labelId = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox5 = new TextBox();
            labelType = new Label();
            labelNumber = new Label();
            labelParent = new Label();
            textBoxData3D = new TextBox();
            label3dData = new Label();
            comboBox4 = new ComboBox();
            labelGeometry = new Label();
            label8 = new Label();
            textBoxGeom = new TextBox();
            textBoxReference = new TextBox();
            buttonMaterialPicker = new Button();
            buttonGeometrySelection = new Button();
            buttonData3DSelector = new Button();
            textBox4 = new TextBox();
            label4 = new Label();
            labelClassType = new Label();
            SuspendLayout();
            // 
            // buttonUpdate
            // 
            buttonUpdate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonUpdate.Location = new Point(452, 351);
            buttonUpdate.Margin = new Padding(3, 2, 3, 2);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(71, 40);
            buttonUpdate.TabIndex = 0;
            buttonUpdate.Text = "update";
            buttonUpdate.UseVisualStyleBackColor = true;
            buttonUpdate.Click += buttonUpdate_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-3, 19);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 1;
            label1.Text = "Name";
            // 
            // textBoxName
            // 
            textBoxName.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBoxName.Location = new Point(101, 16);
            textBoxName.Margin = new Padding(3, 2, 3, 2);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(422, 27);
            textBoxName.TabIndex = 2;
            // 
            // labelidCode
            // 
            labelidCode.AutoSize = true;
            labelidCode.Location = new Point(-3, 51);
            labelidCode.Name = "labelidCode";
            labelidCode.Size = new Size(57, 20);
            labelidCode.TabIndex = 1;
            labelidCode.Text = "idCode";
            // 
            // labelMaterial
            // 
            labelMaterial.AutoSize = true;
            labelMaterial.Location = new Point(0, 87);
            labelMaterial.Name = "labelMaterial";
            labelMaterial.Size = new Size(64, 20);
            labelMaterial.TabIndex = 1;
            labelMaterial.Text = "Material";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(0, 306);
            label10.Name = "label10";
            label10.Size = new Size(93, 20);
            label10.TabIndex = 1;
            label10.Text = "Components";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(0, 160);
            label5.Name = "label5";
            label5.Size = new Size(49, 20);
            label5.TabIndex = 1;
            label5.Text = "Descr.";
            // 
            // labelId
            // 
            labelId.AutoSize = true;
            labelId.Location = new Point(1, 413);
            labelId.Name = "labelId";
            labelId.Size = new Size(22, 20);
            labelId.TabIndex = 1;
            labelId.Text = "Id";
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox2.Location = new Point(101, 48);
            textBox2.Margin = new Padding(2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(422, 27);
            textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            textBox3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox3.Location = new Point(101, 84);
            textBox3.Margin = new Padding(2);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(422, 27);
            textBox3.TabIndex = 2;
            // 
            // textBox5
            // 
            textBox5.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox5.Location = new Point(102, 157);
            textBox5.Margin = new Padding(2);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(422, 27);
            textBox5.TabIndex = 2;
            // 
            // labelType
            // 
            labelType.AutoSize = true;
            labelType.Location = new Point(3, 382);
            labelType.Name = "labelType";
            labelType.Size = new Size(40, 20);
            labelType.TabIndex = 1;
            labelType.Text = "Type";
            // 
            // labelNumber
            // 
            labelNumber.AutoSize = true;
            labelNumber.Location = new Point(4, 351);
            labelNumber.Name = "labelNumber";
            labelNumber.Size = new Size(24, 20);
            labelNumber.TabIndex = 1;
            labelNumber.Text = "n: ";
            labelNumber.DoubleClick += labelNumber_DoubleClick;
            // 
            // labelParent
            // 
            labelParent.AutoSize = true;
            labelParent.Location = new Point(99, 198);
            labelParent.Name = "labelParent";
            labelParent.Size = new Size(12, 20);
            labelParent.TabIndex = 1;
            labelParent.Text = ".";
            // 
            // textBoxData3D
            // 
            textBoxData3D.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBoxData3D.Location = new Point(101, 192);
            textBoxData3D.Margin = new Padding(3, 2, 3, 2);
            textBoxData3D.Name = "textBoxData3D";
            textBoxData3D.Size = new Size(422, 27);
            textBoxData3D.TabIndex = 2;
            // 
            // label3dData
            // 
            label3dData.AutoSize = true;
            label3dData.Location = new Point(0, 198);
            label3dData.Name = "label3dData";
            label3dData.Size = new Size(60, 20);
            label3dData.TabIndex = 1;
            label3dData.Text = "Data3D";
            // 
            // comboBox4
            // 
            comboBox4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(102, 303);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(422, 28);
            comboBox4.TabIndex = 3;
            comboBox4.DropDown += comboBox4_DropDown;
            // 
            // labelGeometry
            // 
            labelGeometry.AutoSize = true;
            labelGeometry.Location = new Point(-3, 232);
            labelGeometry.Name = "labelGeometry";
            labelGeometry.Size = new Size(74, 20);
            labelGeometry.TabIndex = 1;
            labelGeometry.Text = "Geometry";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(0, 270);
            label8.Name = "label8";
            label8.Size = new Size(67, 20);
            label8.TabIndex = 1;
            label8.Text = "Referenz";
            // 
            // textBoxGeom
            // 
            textBoxGeom.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBoxGeom.Location = new Point(99, 228);
            textBoxGeom.Margin = new Padding(3, 2, 3, 2);
            textBoxGeom.Name = "textBoxGeom";
            textBoxGeom.Size = new Size(424, 27);
            textBoxGeom.TabIndex = 2;
            // 
            // textBoxReference
            // 
            textBoxReference.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBoxReference.Location = new Point(99, 265);
            textBoxReference.Margin = new Padding(3, 2, 3, 2);
            textBoxReference.Name = "textBoxReference";
            textBoxReference.Size = new Size(424, 27);
            textBoxReference.TabIndex = 2;
            // 
            // buttonMaterialPicker
            // 
            buttonMaterialPicker.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonMaterialPicker.Enabled = false;
            buttonMaterialPicker.Location = new Point(526, 84);
            buttonMaterialPicker.Margin = new Padding(3, 2, 3, 2);
            buttonMaterialPicker.Name = "buttonMaterialPicker";
            buttonMaterialPicker.Size = new Size(29, 27);
            buttonMaterialPicker.TabIndex = 0;
            buttonMaterialPicker.Text = "...";
            buttonMaterialPicker.UseVisualStyleBackColor = true;
            buttonMaterialPicker.Click += buttonMaterialPicker_Click;
            // 
            // buttonGeometrySelection
            // 
            buttonGeometrySelection.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonGeometrySelection.Enabled = false;
            buttonGeometrySelection.Location = new Point(529, 225);
            buttonGeometrySelection.Margin = new Padding(3, 2, 3, 2);
            buttonGeometrySelection.Name = "buttonGeometrySelection";
            buttonGeometrySelection.Size = new Size(26, 27);
            buttonGeometrySelection.TabIndex = 0;
            buttonGeometrySelection.Text = "...";
            buttonGeometrySelection.UseVisualStyleBackColor = true;
            buttonGeometrySelection.Click += buttonGeometrySelection_Click;
            // 
            // buttonData3DSelector
            // 
            buttonData3DSelector.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonData3DSelector.Enabled = false;
            buttonData3DSelector.Location = new Point(529, 191);
            buttonData3DSelector.Margin = new Padding(3, 2, 3, 2);
            buttonData3DSelector.Name = "buttonData3DSelector";
            buttonData3DSelector.Size = new Size(28, 27);
            buttonData3DSelector.TabIndex = 0;
            buttonData3DSelector.Text = "...";
            buttonData3DSelector.UseVisualStyleBackColor = true;
            buttonData3DSelector.Click += buttonData3DSelector_Click;
            // 
            // textBox4
            // 
            textBox4.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox4.Location = new Point(102, 120);
            textBox4.Margin = new Padding(2);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(422, 27);
            textBox4.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(0, 120);
            label4.Name = "label4";
            label4.Size = new Size(22, 20);
            label4.TabIndex = 1;
            label4.Text = "Id";
            // 
            // labelClassType
            // 
            labelClassType.AutoSize = true;
            labelClassType.Location = new Point(102, 413);
            labelClassType.Name = "labelClassType";
            labelClassType.Size = new Size(42, 20);
            labelClassType.TabIndex = 1;
            labelClassType.Text = "Class";
            // 
            // PartControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            Controls.Add(comboBox4);
            Controls.Add(textBoxReference);
            Controls.Add(textBoxGeom);
            Controls.Add(textBoxData3D);
            Controls.Add(textBox4);
            Controls.Add(textBox5);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBoxName);
            Controls.Add(labelClassType);
            Controls.Add(labelType);
            Controls.Add(labelParent);
            Controls.Add(labelNumber);
            Controls.Add(labelId);
            Controls.Add(label8);
            Controls.Add(labelGeometry);
            Controls.Add(label3dData);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label10);
            Controls.Add(labelMaterial);
            Controls.Add(labelidCode);
            Controls.Add(label1);
            Controls.Add(buttonData3DSelector);
            Controls.Add(buttonGeometrySelection);
            Controls.Add(buttonMaterialPicker);
            Controls.Add(buttonUpdate);
            Margin = new Padding(2);
            Name = "PartControl";
            Size = new Size(610, 477);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.TextBox textBox2;
        protected System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Label labelParent;
        private System.Windows.Forms.TextBox textBoxData3D;
        private System.Windows.Forms.ComboBox comboBox4;
        private Label label8;
        private TextBox textBoxGeom;
        private TextBox textBoxReference;
        protected Button buttonMaterialPicker;
        private Button buttonGeometrySelection;
        private Button buttonData3DSelector;
        private TextBox textBox4;
        private Label label4;
        private Label labelClassType;
        private Label labelidCode;
        private Label labelMaterial;
        private Label label3dData;
        private Label labelGeometry;
    }
}
