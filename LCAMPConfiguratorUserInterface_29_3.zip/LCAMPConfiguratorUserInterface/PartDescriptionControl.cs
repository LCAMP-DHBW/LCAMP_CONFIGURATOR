﻿using LCAMPConfigurator.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LCAMPConfiguratorUserInterface
{
    public partial class PartDescriptionControl : UserControl
    {

        // 1️⃣ Event definieren
        public event Action<(string, string, string, RobComponent)> PartUpdated;

        public PartDescriptionControl()
        {
            InitializeComponent();
            // Erzwingt die Berechnung des Layouts für das gesamte Fenster
          
        }

        public void InitElements(RobComponent part)
        {

        }
    }
}
