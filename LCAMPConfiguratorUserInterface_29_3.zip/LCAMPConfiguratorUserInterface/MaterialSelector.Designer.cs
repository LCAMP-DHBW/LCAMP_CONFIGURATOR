﻿using System.Drawing;
using System.Windows.Forms;
namespace LCAMPConfigurator.UI
{
    public partial class MaterialSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listViewMaterials = new ListView();
            buttonOK = new Button();
            buttonCancel = new Button();
            mainPanel = new TableLayoutPanel();
            toolbarPanel = new Panel();
            label1 = new Label();
            comboBoxFilter = new ComboBox();
            textBoxSearch = new TextBox();
            panelpreViewContainer = new Panel();
            panelColorPreview = new Panel();
            lableColerInfo = new Label();
            buttonPanel = new Panel();
            panelStatus = new Panel();
            labelStatus = new Label();
            mainPanel.SuspendLayout();
            toolbarPanel.SuspendLayout();
            panelpreViewContainer.SuspendLayout();
            buttonPanel.SuspendLayout();
            panelStatus.SuspendLayout();
            SuspendLayout();
            // 
            // listViewMaterials
            // 
            listViewMaterials.Dock = DockStyle.Fill;
            listViewMaterials.FullRowSelect = true;
            listViewMaterials.GridLines = true;
            listViewMaterials.Location = new Point(13, 109);
            listViewMaterials.MultiSelect = false;
            listViewMaterials.Name = "listViewMaterials";
            listViewMaterials.Size = new Size(698, 278);
            listViewMaterials.TabIndex = 2;
            listViewMaterials.UseCompatibleStateImageBehavior = false;
            listViewMaterials.View = View.Details;
            listViewMaterials.SelectedIndexChanged += ListViewMaterials_SelectedIndexChanged;
            // 
            // buttonOK
            // 
            buttonOK.Location = new Point(7, 7);
            buttonOK.Name = "buttonOK";
            buttonOK.Size = new Size(65, 34);
            buttonOK.TabIndex = 0;
            buttonOK.Text = "ok";
            buttonOK.UseVisualStyleBackColor = true;
            buttonOK.Click += ButtonOK_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            buttonCancel.DialogResult = DialogResult.Cancel;
            buttonCancel.Location = new Point(93, 8);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(69, 34);
            buttonCancel.TabIndex = 0;
            buttonCancel.Text = "cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            // 
            // mainPanel
            // 
            mainPanel.ColumnCount = 2;
            mainPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80F));
            mainPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            mainPanel.Controls.Add(listViewMaterials, 0, 2);
            mainPanel.Controls.Add(toolbarPanel, 0, 0);
            mainPanel.Controls.Add(panelpreViewContainer, 1, 2);
            mainPanel.Controls.Add(buttonPanel, 1, 3);
            mainPanel.Controls.Add(panelStatus, 0, 3);
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.Location = new Point(0, 0);
            mainPanel.Name = "mainPanel";
            mainPanel.Padding = new Padding(10);
            mainPanel.RowCount = 4;
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 66F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            mainPanel.Size = new Size(900, 450);
            mainPanel.TabIndex = 3;
            // 
            // toolbarPanel
            // 
            mainPanel.SetColumnSpan(toolbarPanel, 2);
            toolbarPanel.Controls.Add(label1);
            toolbarPanel.Controls.Add(comboBoxFilter);
            toolbarPanel.Controls.Add(textBoxSearch);
            toolbarPanel.Dock = DockStyle.Fill;
            toolbarPanel.Location = new Point(13, 13);
            toolbarPanel.Name = "toolbarPanel";
            toolbarPanel.Size = new Size(874, 60);
            toolbarPanel.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(209, 20);
            label1.Name = "label1";
            label1.Size = new Size(42, 20);
            label1.TabIndex = 2;
            label1.Text = "Filter";
            // 
            // comboBoxFilter
            // 
            comboBoxFilter.FormattingEnabled = true;
            comboBoxFilter.Items.AddRange(new object[] { "all", "3D Print", "LaserJetCut", "WaterJetCut" });
            comboBoxFilter.Location = new Point(266, 17);
            comboBoxFilter.Name = "comboBoxFilter";
            comboBoxFilter.Size = new Size(194, 28);
            comboBoxFilter.TabIndex = 2;
            comboBoxFilter.SelectedIndexChanged += comboBoxFilter_SelectedIndexChanged;
            // 
            // textBoxSearch
            // 
            textBoxSearch.Enabled = false;
            textBoxSearch.Location = new Point(12, 18);
            textBoxSearch.Name = "textBoxSearch";
            textBoxSearch.Size = new Size(181, 27);
            textBoxSearch.TabIndex = 1;
            // 
            // panelpreViewContainer
            // 
            panelpreViewContainer.Controls.Add(panelColorPreview);
            panelpreViewContainer.Controls.Add(lableColerInfo);
            panelpreViewContainer.Dock = DockStyle.Fill;
            panelpreViewContainer.Location = new Point(717, 109);
            panelpreViewContainer.Name = "panelpreViewContainer";
            panelpreViewContainer.Size = new Size(170, 278);
            panelpreViewContainer.TabIndex = 1;
            // 
            // panelColorPreview
            // 
            panelColorPreview.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panelColorPreview.BackColor = SystemColors.ControlLightLight;
            panelColorPreview.Location = new Point(13, 16);
            panelColorPreview.Name = "panelColorPreview";
            panelColorPreview.Size = new Size(149, 69);
            panelColorPreview.TabIndex = 1;
            // 
            // lableColerInfo
            // 
            lableColerInfo.AutoSize = true;
            lableColerInfo.Location = new Point(13, 97);
            lableColerInfo.Name = "lableColerInfo";
            lableColerInfo.Size = new Size(74, 20);
            lableColerInfo.TabIndex = 0;
            lableColerInfo.Text = "Coler Info";
            // 
            // buttonPanel
            // 
            buttonPanel.Controls.Add(buttonCancel);
            buttonPanel.Controls.Add(buttonOK);
            buttonPanel.Dock = DockStyle.Fill;
            buttonPanel.Location = new Point(717, 393);
            buttonPanel.Name = "buttonPanel";
            buttonPanel.Size = new Size(170, 44);
            buttonPanel.TabIndex = 5;
            // 
            // panelStatus
            // 
            panelStatus.Controls.Add(labelStatus);
            panelStatus.Dock = DockStyle.Fill;
            panelStatus.Location = new Point(13, 393);
            panelStatus.Name = "panelStatus";
            panelStatus.Size = new Size(698, 44);
            panelStatus.TabIndex = 6;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Location = new Point(12, 12);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(18, 20);
            labelStatus.TabIndex = 0;
            labelStatus.Text = "...";
            // 
            // MaterialSelector
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 450);
            Controls.Add(mainPanel);
            Name = "MaterialSelector";
            Text = "MaterialSelector";
            mainPanel.ResumeLayout(false);
            toolbarPanel.ResumeLayout(false);
            toolbarPanel.PerformLayout();
            panelpreViewContainer.ResumeLayout(false);
            panelpreViewContainer.PerformLayout();
            buttonPanel.ResumeLayout(false);
            panelStatus.ResumeLayout(false);
            panelStatus.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private ListView listViewMaterials;
        private Button buttonOK;
        private Button buttonCancel;
        private TableLayoutPanel mainPanel;
        private Panel toolbarPanel;
        private Panel panelColorPreview;
        private Panel panelpreViewContainer;
        private Label lableColerInfo;
        private Panel buttonPanel;
        private TextBox textBoxSearch;
        private Panel panelStatus;
        private ComboBox comboBoxFilter;
        protected Label labelStatus;
        private Label label1;
    }
}