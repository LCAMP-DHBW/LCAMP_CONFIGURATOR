﻿#pragma warning disable CA1416


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using LCAMPConfigurator.Core;
using System.Reflection;
using System.Diagnostics;

namespace LCAMPConfigurator.UI
{
    public partial class ControlConsole : Form
    {
        Button buttonConsole;
        ToolStripMenuItem itemConsole;

        public ControlConsole(Button linkedButton)
        {
            InitializeComponent();
            buttonConsole = linkedButton;
            var assembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
          

            Version version = assembly.GetName().Version;


            this.Text = $"Control Console LCAMP-Version: {version}";

        }
        public ControlConsole(ToolStripMenuItem linkedItem) {  
            InitializeComponent();
            itemConsole = linkedItem;

            var assembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
            Version version = assembly.GetName().Version;
            this.Text = $"Control Console LCAMP-Version: {version}";
        }
        



        public void openConsole()
        {


            Thread uiThread = new Thread(() =>
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Console auf TextBox umleiten
            Console.SetOut(new ControlWriter(textBoxOutput));

            //BringToFront();

            Application.Run(this);
        });


            uiThread.SetApartmentState(ApartmentState.STA);
            uiThread.Start();

        }
        public void closeConsole()
        {
            if (!this.IsDisposed)
            {
                if (InvokeRequired)
                {
                    Invoke(new Action(() => Close()));
                }
                else
                {
                    Close();

                }
            }
            // Console auf TextBox umleiten
            Console.SetOut(new DebugTextWriter());
            Console.WriteLine("Das landet jetzt im Visual Studio Debug-Ausgabefenster");

        }

        private void ControlConsole_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Wird ausgelöst, BEVOR das Fenster geschlossen wird
            Console.WriteLine("Console window is closing...");

            // Wenn du das Schließen verhindern willst:
            // e.Cancel = true;
        }

        private void ControlConsole_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Wird ausgelöst, NACHDEM das Fenster geschlossen wurde
            Console.WriteLine("Console window was closed.");

            // Deine Umleitung wieder zurücksetzen
            Console.SetOut(new DebugTextWriter());
            if (buttonConsole != null)
            {
                buttonConsole.BackColor = SystemColors.Control;
                buttonConsole.UseVisualStyleBackColor = true;
           
            }
            if (itemConsole != null)
            {
                itemConsole.BackColor = SystemColors.Control;
            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxOutput.Clear();
        }
        private void buttonCopy_Click(object sender, EventArgs e)
        {
            DataObject data = new DataObject();
            data.SetData(DataFormats.Text, textBoxOutput.Text);
            data.SetData(DataFormats.Rtf, textBoxOutput.Rtf);
            Clipboard.SetDataObject(data);
        }
    }
}
